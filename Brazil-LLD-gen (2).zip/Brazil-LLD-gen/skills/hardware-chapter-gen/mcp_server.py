"""
mcp_server.py
-------------
MCP-over-HTTP server exposing two tools for the hardware chapter generation
pipeline. Place this file in the project root and run:

    python mcp_server.py [--port 8000] [--config config.yaml]

MCP HTTP transport (JSON-RPC 2.0 over HTTP POST):
  POST /mcp  →  { jsonrpc, id, method, params }

Exposed tools:
  1. explore_chapters      — broad CHM search, returns candidate chapters
  2. generate_hardware_chapter — consumes a chapter_plan, returns docx path

The Agent calls these tools in sequence, doing the classification step
(candidates → chapter_plan) itself between the two tool calls.
"""

import sys
import json
import argparse
import subprocess
import tempfile
import traceback
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML not installed. Run: pip install pyyaml", file=sys.stderr)
    sys.exit(1)

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------
def load_config(config_path: str) -> dict:
    path = Path(config_path)
    if not path.exists():
        print(f"ERROR: config file not found: {path}", file=sys.stderr)
        sys.exit(1)
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    # Resolve all paths relative to project root (config file location)
    root = path.parent.resolve()
    for key in ("db_path", "chm_dir", "build_script", "search_script",
                "explore_script", "gen_script", "output_dir"):
        if key in cfg:
            cfg[key] = str((root / cfg[key]).resolve())

    cfg["_root"] = str(root)
    return cfg


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

def tool_explore_chapters(params: dict, cfg: dict) -> dict:
    """
    Broad CHM search for a device model.

    Input params:
        model (str):  device model name, e.g. "CE8850-64CQ-EI"
        top_k (int):  max results per query (default 10)

    Returns:
        { model, candidates: [ {html_path, chapter, snippet, chm} ] }
    """
    model = params.get("model", "").strip()
    if not model:
        raise ValueError("'model' is required")

    top_k = int(params.get("top_k", 10))

    with tempfile.NamedTemporaryFile(
        suffix=".json", delete=False, mode="w", encoding="utf-8"
    ) as tmp:
        out_path = tmp.name

    cmd = [
        sys.executable,
        cfg["explore_script"],
        "--model",         model,
        "--db",            cfg["db_path"],
        "--search-script", cfg["search_script"],
        "--out",           out_path,
        "--top-k",         str(top_k),
    ]

    proc = subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", timeout=120
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"explore_chapters.py failed (exit {proc.returncode}):\n{proc.stderr}"
        )

    result = json.loads(Path(out_path).read_text(encoding="utf-8"))
    Path(out_path).unlink(missing_ok=True)
    return result


def tool_generate_hardware_chapter(params: dict, cfg: dict) -> dict:
    """
    Generate a hardware chapter docx from a chapter plan.

    Input params:
        chapter_plan (dict):  { model, sections: [{html_path, chapter, role,
                                section_title, max_images?}] }
        chapter_start (str):  e.g. "3.3" (optional, uses config default)
        out_subdir (str):     subdirectory under output_dir (optional)

    Returns:
        { docx_path, md_path, model }
    """
    chapter_plan = params.get("chapter_plan")
    if not chapter_plan:
        raise ValueError("'chapter_plan' is required")
    if not isinstance(chapter_plan, dict):
        raise ValueError("'chapter_plan' must be a JSON object")

    model = chapter_plan.get("model", "unknown")
    chapter_start = params.get("chapter_start", cfg.get("chapter_start", "3.3"))
    out_subdir = params.get("out_subdir", f"hardware_{model.replace(' ', '_')}")
    out_dir = Path(cfg["output_dir"]) / out_subdir
    out_dir.mkdir(parents=True, exist_ok=True)

    # Write chapter_plan to a temp file
    plan_path = out_dir / "chapter_plan.json"
    plan_path.write_text(
        json.dumps(chapter_plan, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    cmd = [
        sys.executable,
        cfg["gen_script"],
        "--chapter-plan",  str(plan_path),
        "--out-dir",       str(out_dir),
        "--chapter-start", chapter_start,
    ]

    proc = subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", timeout=300
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"gen_hardware_chapter.py failed (exit {proc.returncode}):\n{proc.stderr}"
        )

    docx_path = out_dir / "hardware_chapter.docx"
    md_path   = out_dir / "hardware_chapter.md"

    return {
        "model":     model,
        "docx_path": str(docx_path),
        "md_path":   str(md_path),
        "out_dir":   str(out_dir),
        "stdout":    proc.stdout[-2000:] if proc.stdout else "",
    }


# ---------------------------------------------------------------------------
# New tools: parse_device_list + explore_all_devices
# ---------------------------------------------------------------------------

def tool_parse_device_list(params: dict, cfg: dict) -> dict:
    """Parse Excel device list, skip servers/appliances, return network devices."""
    excel_path = params.get("excel_path", "").strip()
    if not excel_path:
        raise ValueError("'excel_path' is required")

    root = Path(cfg["_root"])
    path = Path(excel_path)
    if not path.is_absolute():
        path = root / path
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {path}")

    parse_script = root / "skills" / "hardware-chapter-gen" / "scripts" / "parse_device_list.py"

    with tempfile.NamedTemporaryFile(
        suffix=".json", delete=False, mode="w", encoding="utf-8"
    ) as tmp:
        out_path = tmp.name

    cmd = [sys.executable, str(parse_script), "--excel", str(path), "--out", out_path]
    if params.get("sheet"):
        cmd += ["--sheet", params["sheet"]]
    if params.get("model_col"):
        cmd += ["--model-col", params["model_col"]]
    if params.get("role_col"):
        cmd += ["--role-col", params["role_col"]]

    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", timeout=60)
    if proc.returncode != 0:
        raise RuntimeError(f"parse_device_list.py failed:\n{proc.stderr}")

    result = json.loads(Path(out_path).read_text(encoding="utf-8"))
    Path(out_path).unlink(missing_ok=True)
    return result


def tool_explore_all_devices(params: dict, cfg: dict) -> dict:
    """Run explore_chapters for every device in a device_list in one call."""
    device_list = params.get("device_list", [])
    if not device_list:
        raise ValueError("'device_list' is required and must be non-empty")

    top_k = int(params.get("top_k", 10))
    results = {}

    for device in device_list:
        model = device.get("model", "").strip()
        if not model:
            continue
        print(f"  Exploring: {model}")
        try:
            results[model] = tool_explore_chapters({"model": model, "top_k": top_k}, cfg)
        except Exception as e:
            results[model] = {"model": model, "candidates": [], "error": str(e)}

    return {"results": results}


# ---------------------------------------------------------------------------
# MCP tool registry
# ---------------------------------------------------------------------------

TOOLS = {
    "parse_device_list": {
        "description": (
            "Parse an Excel (.xlsx) file containing a device list table and extract "
            "unique network device models. Automatically skips servers and appliances. "
            "Returns a structured device list ready for hardware chapter generation. "
            "Call this first when the user uploads an Excel file."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "excel_path": {
                    "type": "string",
                    "description": "Path to the Excel file (absolute or relative to project root)"
                },
                "sheet": {
                    "type": "string",
                    "description": "Sheet name (auto-detected if omitted)"
                },
                "model_col": {
                    "type": "string",
                    "description": "Column header for device model (default: 'Device Model')"
                },
                "role_col": {
                    "type": "string",
                    "description": "Column header for device role (default: 'Device Role')"
                }
            },
            "required": ["excel_path"]
        },
        "fn": tool_parse_device_list,
    },
    "explore_chapters": {
        "description": (
            "Search the CHM/HDX product manual index for a single device model and "
            "return candidate chapters for Agent classification."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "model": {"type": "string", "description": "Device model name"},
                "top_k": {"type": "integer", "description": "Max results per query (default 10)", "default": 10}
            },
            "required": ["model"]
        },
        "fn": tool_explore_chapters,
    },
    "explore_all_devices": {
        "description": (
            "Run explore_chapters for every device in a device list in one call. "
            "Use this after parse_device_list to get candidates for all devices at once."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "device_list": {
                    "type": "array",
                    "description": "List of device objects from parse_device_list (each must have 'model')",
                    "items": {"type": "object"}
                },
                "top_k": {"type": "integer", "description": "Max results per device (default 10)", "default": 10}
            },
            "required": ["device_list"]
        },
        "fn": tool_explore_all_devices,
    },
    "generate_hardware_chapter": {
        "description": (
            "Generate a hardware chapter .docx from a chapter_plan produced by the Agent. "
            "Returns the path to the generated docx file."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "chapter_plan": {
                    "type": "object",
                    "description": (
                        "{ model, sections: [{html_path, chapter, role, section_title, max_images}] }. "
                        "Valid roles: appearance | chassis_overview | specifications | sub_component"
                    )
                },
                "chapter_start": {"type": "string", "description": "Starting section number e.g. '3.3'", "default": "3.3"},
                "out_subdir":    {"type": "string", "description": "Output subdirectory under output/"}
            },
            "required": ["chapter_plan"]
        },
        "fn": tool_generate_hardware_chapter,
    },
}


# ---------------------------------------------------------------------------
# MCP protocol helpers
# ---------------------------------------------------------------------------

def mcp_result(id_, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": id_, "result": result}


def mcp_error(id_, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": id_, "error": {"code": code, "message": message}}


def handle_rpc(body: dict, cfg: dict) -> dict:
    method = body.get("method", "")
    id_    = body.get("id")
    params = body.get("params", {})

    # --- initialize ---
    if method == "initialize":
        return mcp_result(id_, {
            "protocolVersion": "2024-11-05",
            "capabilities":    {"tools": {}},
            "serverInfo":      {"name": "hardware-chapter-gen", "version": "1.0.0"},
        })

    # --- tools/list ---
    if method == "tools/list":
        tools_list = []
        for name, spec in TOOLS.items():
            tools_list.append({
                "name":        name,
                "description": spec["description"],
                "inputSchema": spec["inputSchema"],
            })
        return mcp_result(id_, {"tools": tools_list})

    # --- tools/call ---
    if method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})

        if tool_name not in TOOLS:
            return mcp_error(id_, -32601, f"Unknown tool: {tool_name}")

        try:
            result = TOOLS[tool_name]["fn"](tool_args, cfg)
            return mcp_result(id_, {
                "content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}]
            })
        except Exception as e:
            tb = traceback.format_exc()
            print(f"[ERROR] tool={tool_name}\n{tb}", file=sys.stderr)
            return mcp_error(id_, -32000, str(e))

    return mcp_error(id_, -32601, f"Method not found: {method}")


# ---------------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------------

class MCPHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        print(f"[{self.address_string()}] {self.command} {self.path} - {fmt % args}")

    def do_POST(self):
        print(f"[DEBUG] POST {self.path}", file=sys.stderr)
        length = int(self.headers.get("Content-Length", 0))
        raw    = self.rfile.read(length)
        print(f"[DEBUG] Body: {raw[:500]}", file=sys.stderr)

        # Accept requests on any path
        try:
            body = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as e:
            self._send_json({"jsonrpc": "2.0", "id": None,
                             "error": {"code": -32700, "message": f"Parse error: {e}"}})
            return

        response = handle_rpc(body, self.server.cfg)
        self._send_json(response)

    def do_GET(self):
        print(f"[DEBUG] GET {self.path}", file=sys.stderr)
        self._send_json({"status": "ok", "server": "hardware-chapter-gen-mcp"})

    def _send_json(self, data: dict):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type",   "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class MCPServer(HTTPServer):
    def __init__(self, addr, handler, cfg):
        super().__init__(addr, handler)
        self.cfg = cfg


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Hardware Chapter Gen — MCP HTTP Server")
    parser.add_argument("--port",   type=int, default=8000, help="Port to listen on (default 8000)")
    parser.add_argument("--host",   default="127.0.0.1",   help="Host to bind (default 127.0.0.1)")
    parser.add_argument("--config", default="config.yaml", help="Path to config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)

    print(f"Hardware Chapter Gen MCP Server")
    print(f"  Listening : http://{args.host}:{args.port}/mcp")
    print(f"  Project   : {cfg.get('project', '?')}")
    print(f"  DB        : {cfg.get('db_path', '?')}")
    print(f"  Output    : {cfg.get('output_dir', '?')}")
    print()

    server = MCPServer((args.host, args.port), MCPHandler, cfg)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")


if __name__ == "__main__":
    main()