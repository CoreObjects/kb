---
name: hardware-chapter-gen
description: >
  Generate the hardware introduction chapter of a network LLD document from a
  device list. Searches Huawei product manuals (CHM/HDX) for each device model,
  extracts hardware description content, and assembles a structured LLD hardware
  chapter as a .docx file. ALWAYS use this skill when the user provides a list
  of network device models and wants to generate or populate the hardware
  section of an LLD. Triggers: "生成硬件章节", "hardware chapter", "设备介绍",
  "填充硬件介绍", "generate hardware section", "device list to LLD".
  Depends on: chm-search skill (scripts/search.py must be available and
  index.db must already be built).

---

# Hardware Chapter Generator Skill

## What it does

1. Accepts a device list (model names) as input — from a YAML/JSON file,
   a plain text list, or a natural-language description.
2. For each device, runs targeted searches against the CHM/HDX index
   (built by the `chm-search` skill) to retrieve hardware description content.
3. Extracts and cleans the relevant text from matched HTML pages.
4. Assembles all content into a structured LLD hardware chapter following
   the standard Alloha LLD section numbering convention.
5. Outputs a ready-to-use `.docx` file via the `docx` skill (docx-js).

## Dependencies — verify before running

| Dependency | Role | Verify |
|---|---|---|
| Python ≥ 3.10 + `beautifulsoup4` | HTML content extraction | `python -c "import bs4"` |
| `chm-search` index.db | Source of hardware content | file must exist at `--db` path |
| `chm-search/scripts/search.py` | Query the index | path passed via `--search-script` |
| Node.js + `docx` npm package | Generate .docx output | `node -e "require('docx')"` |

If `index.db` does not exist, run the `chm-search` skill's `build_index.py`
first to index the relevant CHM/HDX manuals before using this skill.

## Files

- `scripts/gen_hardware_chapter.py` — main orchestration script
- `scripts/render_docx.js` — docx-js rendering script

## Usage

### 首次使用（index.db 尚不存在，自动建库）

只需提供 CHM 目录和 build_index.py 路径，脚本会自动建库后继续生成章节：

```bash
python scripts/gen_hardware_chapter.py \
  --devices "NE8000-X4,NE8000-F2C,NE8000-F1A" \
  --db ./manuals/index.db \
  --chm-dir ./manuals \
  --build-script ./chm-search/scripts/build_index.py \
  --search-script ./chm-search/scripts/search.py \
  --out-dir ./output \
  --chapter-start 3.3
```

### 后续使用（index.db 已存在，直接跳过建库）

```bash
python scripts/gen_hardware_chapter.py \
  --devices "NE8000-X4,NE8000-F2C,NE8000-F1A" \
  --db ./manuals/index.db \
  --search-script ./chm-search/scripts/search.py \
  --out-dir ./output \
  --chapter-start 3.3
```

### 使用设备文件（每行一个型号，或 JSON 数组）

```bash
python scripts/gen_hardware_chapter.py \
  --devices-file devices.txt \
  --db ./manuals/index.db \
  --search-script ./chm-search/scripts/search.py \
  --out-dir ./output
```

### Arguments

| 参数 | 是否必填 | 默认值 | 说明 |
|---|---|---|---|
| `--devices` | 二选一 | — | 逗号分隔的设备型号 |
| `--devices-file` | 二选一 | — | 设备型号文件（txt 每行一个，或 JSON 数组） |
| `--db` | ✅ | — | index.db 路径（不存在时自动建库） |
| `--search-script` | ✅ | — | chm-search/scripts/search.py 路径 |
| `--out-dir` | ✅ | — | 输出目录 |
| `--chm-dir` | 自动建库时必填 | — | 存放 .chm/.hdx 文件的目录，index.db 缺失时触发自动建库 |
| `--build-script` | 自动建库时必填 | — | chm-search/scripts/build_index.py 路径 |
| `--chapter-start` | 可选 | `3.3` | 第一个设备的起始章节编号 |
| `--top-k` | 可选 | `3` | 每个查询最多返回的搜索结果数 |

### 自动建库触发逻辑

```
index.db 存在且非空 → 跳过建库，直接进入搜索
index.db 不存在或为空
  ├── 未提供 --chm-dir 或 --build-script → 报错退出，提示手动建库
  ├── --chm-dir 目录不存在 → 报错退出
  ├── 扫描 --chm-dir 下的 *.zip
  │   ├── 发现 zip → 逐个解压，提取其中的 .chm/.hdx 到同目录
  │   │   注：zip 内的 CHM 通常覆盖多个设备型号，FTS5 索引会将所有章节一并收录
  │   └── 解压完成后继续
  ├── 仍无 .chm/.hdx 可用 → 报错退出（zip 内容有误）
  └── 一切就绪 → 自动运行 build_index.py，完成后继续
```

### manuals 目录说明

`references/manuals/` 下的 zip 文件是华为 HedEx 标准分发格式：
- **一个 zip → 一个 CHM**，但该 CHM 内部包含多个设备型号的章节
- 不需要手动解压，`ensure_index()` 会在首次运行时自动处理
- 解压出的 `.chm` 文件会留在 `manuals/` 目录，后续运行直接跳过解压步骤
- `index.db` 也生成在 `manuals/` 目录下

## Workflow

This skill operates in two modes:

### Mode A: Agent-driven (recommended)

The upstream Agent controls chapter selection. The skill only handles data
retrieval and rendering — all classification decisions stay with the Agent.

```
Step 1: explore_chapters.py  →  candidates.json   (broad search, no filtering)
Step 2: Agent classifies candidates  →  chapter_plan.json
Step 3: gen_hardware_chapter.py --chapter-plan  →  hardware_chapter.docx
```

**Step 1 — Explore**
```bash
python scripts/explore_chapters.py \
  --model "CE8850-64CQ-EI" \
  --db manuals/index.db \
  --search-script skills/chm-search-skill/scripts/search.py \
  --out output/candidates.json
```

**Step 2 — Agent classifies** (upstream Agent reads candidates.json and writes chapter_plan.json)

`candidates.json` structure:
```json
{
  "model": "CE8850-64CQ-EI",
  "candidates": [
    {
      "html_path": "...chassis_02351RFF-004.html",
      "chapter": "Hardware Description › Chassis › CE8850-64CQ-EI › CE8850-64CQ-EI (02351RFF-004)",
      "snippet": "...Appearance of the CE8850..."
    }
  ]
}
```

`chapter_plan.json` structure (produced by Agent):
```json
{
  "model": "CE8850-64CQ-EI",
  "sections": [
    {
      "html_path": "...dc_dc_88_pd_0002_v2r20c10.html",
      "chapter": "Product Description › Product Appearance",
      "role": "appearance",
      "section_title": "CE8850-64CQ-EI Bayface Design"
    },
    {
      "html_path": "...ce_box_chassis_02351RFF-004.html",
      "chapter": "Hardware Description › Chassis › CE8850-64CQ-EI",
      "role": "chassis_overview",
      "section_title": "Componentes de Hardware CE8850-64CQ-EI"
    },
    {
      "html_path": "...specifications.html",
      "chapter": "Hardware Description › Chassis › CE8850-64CQ-EI › Specifications",
      "role": "specifications",
      "section_title": "Especificações Técnicas CE8850-64CQ-EI"
    }
  ]
}
```

Valid `role` values and their assembly behaviour:

| Role | Behaviour |
|---|---|
| `appearance` | Emitted first; images shown before tables |
| `chassis_overview` | Main component description section |
| `specifications` | All tables go into a dedicated spec sub-section |
| `sub_component` | Appended as optional sub-sections (Agent decides whether to include) |
| (omitted) | Page is skipped — Agent does not include it in the plan |

**Step 3 — Generate**
```bash
python scripts/gen_hardware_chapter.py \
  --chapter-plan output/chapter_plan.json \
  --out-dir output/hardware_chapter \
  --chapter-start 3.3
```

---

### Mode B: Legacy device-list (auto search, no Agent)

Useful for quick tests without an Agent in the loop. Uses heuristic query
templates and hard-coded filters — less accurate than Mode A.

```bash
python scripts/gen_hardware_chapter.py \
  --devices "CE8850-64CQ-EI" \
  --db manuals/index.db \
  --search-script skills/chm-search-skill/scripts/search.py \
  --out-dir output/hardware_chapter \
  --chapter-start 3.3
```

Auto-build (first run only, when index.db does not exist):
```bash
python scripts/gen_hardware_chapter.py \
  --devices "CE8850-64CQ-EI" \
  --db manuals/index.db \
  --chm-dir manuals \
  --build-script skills/chm-search-skill/scripts/build_index.py \
  --search-script skills/chm-search-skill/scripts/search.py \
  --out-dir output/hardware_chapter
```

## Output structure example

Given devices `["NE8000-X4", "NE8000-F2C", "NE8000-F1A"]` and
`--chapter-start 3.3`:

```
3.3  Introdução Huawei NE8000 Series
3.4  NE8000-X4 Bayface Design Super Core
3.4.1  Componentes de Hardware NE8000-X4
3.4.2  NetEngine 8000 Main Processing Unit (MPUA10)
3.4.3  NetEngine 8000 X4 9.6Tbps Switch Fabric Unit (SFU)
3.4.4  NetEngine 8000 X4 LPUI-4T-CM
3.5  NE8000-F2C Bayface Design
3.5.1  Componentes de Hardware NE8000-F2C
3.6  NE8000-F1A Bayface Design
3.6.1  Componentes de Hardware NE8000-F1A
```

## Handling missing content

If a search query returns no results for a device:
- The section is still created with a placeholder:
  `[CONTEÚDO NÃO ENCONTRADO — verificar manual: {model}]`
- A warning is printed to stderr listing all devices with missing content
- The script exits 0 (partial output is still useful)

This prevents silent gaps and makes it easy for the engineer to identify
which sections need manual completion.

## Known limitations

- Only works with CHM/HDX manuals already indexed by `chm-search`
- JS-rendered tab content in manuals may be incomplete (static parsing only)
- Specification tables with merged cells may not convert cleanly
- Component sub-section detection relies on Huawei's standard chapter naming;
  non-standard manual structures may produce fewer sub-sections