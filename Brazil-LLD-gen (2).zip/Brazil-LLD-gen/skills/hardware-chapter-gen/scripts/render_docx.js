/**
 * render_docx.js  v2
 * ------------------
 * Reads hardware_chapter.md and renders a formatted .docx file.
 *
 * New in v2:
 *   - Image support: recognises !!IMAGE!!/abs/path!! markers and inserts
 *     the image inline using docx ImageRun
 *   - Spec tables auto-detected and styled differently from component tables
 *
 * Usage:
 *   node render_docx.js --input hardware_chapter.md --output hardware_chapter.docx
 */

"use strict";

const fs   = require("fs");
const path = require("path");

const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  HeadingLevel, BorderStyle, WidthType, ShadingType,
  ImageRun, AlignmentType, PageBreak, TableOfContents,
} = require("docx");

// ---------------------------------------------------------------------------
// CLI args
// ---------------------------------------------------------------------------
const args = {};
process.argv.slice(2).forEach((val, i, arr) => {
  if (val.startsWith("--")) args[val.slice(2)] = arr[i + 1];
});

const inputPath    = args["input"];
const outputPath   = args["output"];
const chapterStart = args["chapter-start"] || "3.3";

if (!inputPath || !outputPath) {
  console.error("Usage: node render_docx.js --input <md> --output <docx>");
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const COLORS = {
  h1Bg:      "1F5C99",
  h2Bg:      "2E75B6",
  h3Bg:      "D6E4F0",
  tableHdr:  "D5E8F0",
  specHdr:   "E8F4E8",
  warning:   "FFF3CD",
  white:     "FFFFFF",
  text:      "000000",
};
const FONT  = "Arial";
const A4W   = 9026;   // content width in DXA (A4, 2.5cm margins each side)
const IMAGE_MARKER_RE = /^!!IMAGE!!(.+)!!$/;

// ---------------------------------------------------------------------------
// Markdown parser
// Handles the subset produced by gen_hardware_chapter.py
// ---------------------------------------------------------------------------
function parseMd(text) {
  const lines  = text.split(/\r?\n/);
  const blocks = [];

  for (const line of lines) {
    // Image marker
    const imgM = line.match(IMAGE_MARKER_RE);
    if (imgM) { blocks.push({ type: "image", path: imgM[1].trim() }); continue; }

    // Headings
    const h4 = line.match(/^#{4}\s+(.+)/);
    if (h4) { blocks.push({ type: "heading", level: 3, text: h4[1] }); continue; }
    const h3 = line.match(/^#{3}\s+(.+)/);
    if (h3) { blocks.push({ type: "heading", level: 2, text: h3[1] }); continue; }
    const h2 = line.match(/^#{2}\s+(.+)/);
    if (h2) { blocks.push({ type: "heading", level: 1, text: h2[1] }); continue; }

    // HR
    if (/^---+$/.test(line.trim())) { blocks.push({ type: "rule" }); continue; }

    // Blockquote
    const bq = line.match(/^>\s*(.*)/);
    if (bq) { blocks.push({ type: "blockquote", text: bq[1] }); continue; }

    // Table row
    if (line.startsWith("|")) {
      if (/^\|\s*[-:]+/.test(line)) {
        const last = blocks[blocks.length - 1];
        if (last && last.type === "table") last.hasHeader = true;
        continue;
      }
      const cells = line.split("|").slice(1, -1).map(c => c.trim());
      const last  = blocks[blocks.length - 1];
      if (last && last.type === "table") {
        last.rows.push(cells);
      } else {
        blocks.push({ type: "table", rows: [cells], hasHeader: false, isSpec: false });
      }
      continue;
    }

    // Bold paragraph
    const bold = line.match(/^\*\*(.+)\*\*$/);
    if (bold) { blocks.push({ type: "bold", text: bold[1] }); continue; }

    // Blank
    if (!line.trim()) { blocks.push({ type: "blank" }); continue; }

    // Normal paragraph
    blocks.push({ type: "para", text: line });
  }

  // Mark spec tables: first-row headers contain spec keywords
  const specKw = ["item", "specification", "parameter", "dimension", "weight", "power consumption"];
  for (const b of blocks) {
    if (b.type === "table" && b.rows.length > 0) {
      const hdr = b.rows[0].join(" ").toLowerCase();
      b.isSpec = specKw.some(kw => hdr.includes(kw));
    }
  }

  return blocks;
}

// ---------------------------------------------------------------------------
// docx element builders
// ---------------------------------------------------------------------------

function makeHeading1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text, bold: true, font: FONT, size: 28, color: COLORS.white })],
    shading:  { fill: COLORS.h1Bg, type: ShadingType.CLEAR },
    spacing:  { before: 320, after: 160 },
  });
}

function makeHeading2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, bold: true, font: FONT, size: 24, color: COLORS.white })],
    shading:  { fill: COLORS.h2Bg, type: ShadingType.CLEAR },
    spacing:  { before: 240, after: 120 },
  });
}

function makeHeading3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    children: [new TextRun({ text, bold: true, font: FONT, size: 22, color: COLORS.text })],
    shading:  { fill: COLORS.h3Bg, type: ShadingType.CLEAR },
    spacing:  { before: 180, after: 100 },
  });
}

function makePara(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({
      text,
      font:  FONT,
      size:  opts.size  || 20,
      bold:  opts.bold  || false,
      color: opts.color || COLORS.text,
    })],
    spacing: { before: 60, after: 60 },
    shading: opts.shading,
  });
}

function makeWarning(text) {
  const clean = text.replace(/\*\*/g, "").replace(/⚠️\s*/g, "⚠ ");
  return new Paragraph({
    children: [new TextRun({ text: clean, font: FONT, size: 20, bold: true, color: "7B3F00" })],
    shading:  { fill: COLORS.warning, type: ShadingType.CLEAR },
    spacing:  { before: 120, after: 120 },
    indent:   { left: 360 },
    border:   { left: { style: BorderStyle.SINGLE, size: 12, color: "FFC107", space: 6 } },
  });
}

const BORDER_THIN = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const ALL_BORDERS = { top: BORDER_THIN, bottom: BORDER_THIN, left: BORDER_THIN, right: BORDER_THIN };

function makeTable(rows, hasHeader, isSpec) {
  if (!rows || rows.length === 0) return null;
  const colCount = Math.max(...rows.map(r => r.length));
  const colW     = Math.floor(A4W / colCount);
  const colWidths = Array(colCount).fill(colW);

  const hdrColor = isSpec ? COLORS.specHdr : COLORS.tableHdr;

  const tableRows = rows.map((cells, ri) => {
    const isHdr = hasHeader && ri === 0;
    return new TableRow({
      tableHeader: isHdr,
      children: cells.map((cell, ci) =>
        new TableCell({
          borders: ALL_BORDERS,
          width:   { size: colWidths[ci] || colW, type: WidthType.DXA },
          shading: isHdr
            ? { fill: hdrColor, type: ShadingType.CLEAR }
            : { fill: COLORS.white, type: ShadingType.CLEAR },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({
            children: [new TextRun({ text: cell, font: FONT, size: 18, bold: isHdr })],
          })],
        })
      ),
    });
  });

  return new Table({
    width:        { size: A4W, type: WidthType.DXA },
    columnWidths: colWidths,
    rows:         tableRows,
  });
}

// ---------------------------------------------------------------------------
// Image builder
// Returns an array of docx children (Paragraph wrapping ImageRun)
// Returns [] if the image cannot be read or is too large.
// ---------------------------------------------------------------------------
function makeImage(imgPath) {
  try {
    const data = fs.readFileSync(imgPath);
    const ext  = path.extname(imgPath).toLowerCase().replace(".", "");

    // Map extension to docx ImageRun type
    const typeMap = { png: "png", jpg: "jpg", jpeg: "jpg", gif: "gif", bmp: "bmp" };
    const imgType = typeMap[ext];
    if (!imgType) return [];

    // Scale image to fit within content width (max 14cm wide @ 96dpi ≈ 530px)
    // We don't read actual dimensions here — use a safe default max width
    const MAX_WIDTH_EMU  = 6096000;  // ~16.9cm in EMU (1cm = 360000 EMU)
    const MAX_HEIGHT_EMU = 3429000;  // ~9.5cm

    return [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing:   { before: 120, after: 120 },
        children: [
          new ImageRun({
            data,
            transformation: { width: 530, height: 298 },  // px, ~16:9 safe default
            type: imgType,
          }),
        ],
      }),
    ];
  } catch (err) {
    console.warn(`[WARN] Could not embed image: ${imgPath} — ${err.message}`);
    return [];
  }
}

// ---------------------------------------------------------------------------
// Convert parsed blocks → docx children array
// ---------------------------------------------------------------------------
function blocksToDocx(blocks) {
  const children = [];

  for (const block of blocks) {
    switch (block.type) {

      case "heading":
        if      (block.level === 1) children.push(makeHeading1(block.text));
        else if (block.level === 2) children.push(makeHeading2(block.text));
        else                        children.push(makeHeading3(block.text));
        break;

      case "para":
        children.push(makePara(block.text));
        break;

      case "bold":
        children.push(makePara(block.text, { bold: true }));
        break;

      case "blockquote":
        children.push(makeWarning(block.text));
        break;

      case "image":
        children.push(...makeImage(block.path));
        break;

      case "table": {
        const tbl = makeTable(block.rows, block.hasHeader, block.isSpec);
        if (tbl) {
          children.push(tbl);
          children.push(new Paragraph({ children: [], spacing: { after: 120 } }));
        }
        break;
      }

      case "rule":
        children.push(new Paragraph({
          children: [],
          border:   { bottom: { style: BorderStyle.SINGLE, size: 6, color: "2E75B6", space: 1 } },
          spacing:  { before: 240, after: 240 },
        }));
        break;

      case "blank":
        break;  // spacing handled per-element
    }
  }

  return children;
}

// ---------------------------------------------------------------------------
// Build document
// ---------------------------------------------------------------------------
function buildDocument(mdText) {
  const blocks  = parseMd(mdText);
  const content = blocksToDocx(blocks);

  const toc = new TableOfContents("Índice", {
    hyperlink:         true,
    headingStyleRange: "1-3",
  });

  return new Document({
    styles: {
      paragraphStyles: [
        {
          id: "Heading1", name: "Heading 1",
          basedOn: "Normal", next: "Normal", quickFormat: true,
          run:       { size: 28, bold: true, font: FONT, color: COLORS.white },
          paragraph: { spacing: { before: 320, after: 160 }, outlineLevel: 0 },
        },
        {
          id: "Heading2", name: "Heading 2",
          basedOn: "Normal", next: "Normal", quickFormat: true,
          run:       { size: 24, bold: true, font: FONT, color: COLORS.white },
          paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 },
        },
        {
          id: "Heading3", name: "Heading 3",
          basedOn: "Normal", next: "Normal", quickFormat: true,
          run:       { size: 22, bold: true, font: FONT, color: COLORS.text },
          paragraph: { spacing: { before: 180, after: 100 }, outlineLevel: 2 },
        },
      ],
    },
    sections: [{
      properties: {
        page: {
          size:   { width: 11906, height: 16838 },  // A4
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      children: [
        toc,
        new Paragraph({ children: [new PageBreak()] }),
        ...content,
      ],
    }],
  });
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
const mdText = fs.readFileSync(inputPath, "utf-8");
const doc    = buildDocument(mdText);

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(outputPath, buf);
  console.log(`docx written: ${outputPath}`);
}).catch(err => {
  console.error("render_docx.js error:", err);
  process.exit(1);
});