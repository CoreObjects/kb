"""
gen_hardware_chapter.py
-----------------------
Orchestrates the hardware chapter generation pipeline:
  device list → CHM search → HTML extraction → markdown assembly → docx

Changes vs v1:
  - Deduplication: paragraph-level fingerprinting removes near-duplicate content
    from pages covering the same part number (e.g. 02351RFF-001 vs 02351RFF-004)
  - LLD-style content: prioritises product overview / spec pages; filters out
    installation-procedure paragraphs (step-by-step mounting instructions)
  - Image support: extracts <img> src paths, resolves them to disk, passes
    absolute paths to render_docx.js via !!IMAGE!! markers in the intermediate
    markdown file

Usage:
    python gen_hardware_chapter.py \
        --devices "NE8000-X4,NE8000-F2C,NE8000-F1A" \
        --db ./manuals/index.db \
        --search-script ./chm-search/scripts/search.py \
        --out-dir ./output \
        --chapter-start 3.3
"""

import sys
import os
import json
import hashlib
import argparse
import subprocess
import re
from pathlib import Path

# Force UTF-8 output on all platforms (including Windows cp936)
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

try:
    from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
    import warnings
    warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)
except ImportError:
    print("ERROR: beautifulsoup4 not installed. Run: pip install beautifulsoup4", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Search query templates per device
# Ordered by LLD relevance: overview first, specs second, components third.
# Installation/mounting queries removed — they produce procedure content,
# not the descriptive hardware overview an LLD requires.
# ---------------------------------------------------------------------------
QUERY_TEMPLATES = [
    "{model} appearance chassis hardware description",
    "{model} product appearance figure panel",
    "{model} product description overview",
    "{model} hardware description chassis",
    "{model} specifications technical",
    "{model} panel ports interfaces indicators",
]

# Chapter breadcrumb patterns that indicate sub-component pages to skip.
# These pages (power modules, fan modules) add noise; the chassis page
# already summarises slot/module information.
SKIP_CHAPTER_PATTERNS = [
    re.compile(r"power module", re.IGNORECASE),
    re.compile(r"fan module", re.IGNORECASE),
    re.compile(r"optical module", re.IGNORECASE),
    re.compile(r"cable assembly", re.IGNORECASE),
]

# Minimum usable text length
MIN_TEXT_LENGTH = 100

# ---------------------------------------------------------------------------
# Paragraphs matching these patterns are installation procedures.
# Filter them out for LLD-style descriptive output.
# ---------------------------------------------------------------------------
INSTALL_PROCEDURE_PATTERNS = [
    r"^\s*step\s+\d+",
    r"before installing",
    r"installation procedure",
    r"mount the (guide rail|bracket|switch)",
    r"use (four|two|three|the) (m4|m6|screws?)",
    r"tighten the screws?",
    r"remove the (blank|cover|module)",
    r"insert the.*into the slot",
    r"slide the.*until",
    r"figure \d+ (shows?|illustrates?|installing)",
    r"^\s*\d+\.\s+(remove|insert|slide|tighten|connect|disconnect|press|push|pull)",
]
_INSTALL_RE = [re.compile(p, re.IGNORECASE) for p in INSTALL_PROCEDURE_PATTERNS]

# ---------------------------------------------------------------------------
# Additional noise patterns — boilerplate / junk paragraphs to discard
# ---------------------------------------------------------------------------
NOISE_PATTERNS = [
    # URLs and web links
    r"https?://\S+",
    # Huawei Info-Finder / hardware centre boilerplate
    r"info-finder",
    r"hardware (center|centre)",
    r"figures? in this document are for reference only",
    r"ordering information.*subject to change",
    r"contact.*sales personnel",
    r"obtain.*datasheet",
    r"hardware mapping data",
    # Bare part number lines  e.g. "02351RFH-004 (CE8850...)"
    r"^\s*0\d{7}[A-Z0-9\-]+\s*\(",
    # Isolated voltage/power/BTU fragments (no sentence structure)
    r"^\s*\d+[\.,]?\d*\s*(v ac|v dc|w |btu|hz|mbit|gbit|db\(a\))",
    # "Applicable fan/power modules:" fragment lines
    r"^applicable (fan|power|optical) modules?:?\s*$",
    # "For more details, see..."
    r"^for more details,?\s*see",
    # Scan QR code boilerplate
    r"scan the code to view",
    r"esn and mac address",
    # Version history lines
    r"^v\d+r\d+[a-z0-9]*(spc|c)\d+\s*(->|to|→)",
]
_NOISE_RE = [re.compile(p, re.IGNORECASE) for p in NOISE_PATTERNS]


def _is_noise(text: str) -> bool:
    """Return True if paragraph is boilerplate/junk that should be discarded."""
    return any(rx.search(text) for rx in _NOISE_RE)

# ---------------------------------------------------------------------------
# Section title templates (Portuguese — standard Alloha LLD style)
# ---------------------------------------------------------------------------
SECTION_TITLES = {
    "series_intro": "Introdução Huawei {series} Series",
    "bayface":      "{model} Bayface Design",
    "components":   "Componentes de Hardware {model}",
    "specs":        "Especificações Técnicas {model}",
}

# Image marker embedded in intermediate markdown; render_docx.js reads this
IMAGE_MARKER = "!!IMAGE!!{path}!!"


# ---------------------------------------------------------------------------
# Step 1: Parse device list
# ---------------------------------------------------------------------------
def parse_devices(args) -> list[str]:
    if args.devices:
        return [d.strip() for d in args.devices.split(",") if d.strip()]
    if args.devices_file:
        path = Path(args.devices_file)
        text = path.read_text(encoding="utf-8")
        if path.suffix == ".json":
            return json.loads(text)
        return [l.strip() for l in text.splitlines() if l.strip() and not l.startswith("#")]
    raise ValueError("Provide --devices or --devices-file")


# ---------------------------------------------------------------------------
# Step 2: Search CHM index for a single device
# ---------------------------------------------------------------------------
def search_device(model: str, db_path: str, search_script: str, top_k: int) -> list[dict]:
    seen_paths: set[str] = set()
    results: list[dict] = []

    for template in QUERY_TEMPLATES:
        query = template.format(model=model)
        cmd = [
            sys.executable, search_script,
            "--db", db_path,
            "-q", query,
            "--json",
        ]
        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", timeout=30)
        except subprocess.TimeoutExpired:
            print(f"  [WARN] Search timed out: {query!r}", file=sys.stderr)
            continue
        except FileNotFoundError:
            print(f"ERROR: search script not found: {search_script}", file=sys.stderr)
            sys.exit(1)

        if proc.returncode != 0:
            continue

        try:
            hits = json.loads(proc.stdout)
        except json.JSONDecodeError:
            continue

        for hit in hits[:top_k]:
            html_path = hit.get("html_path", "")
            chapter   = hit.get("chapter", "")
            if not html_path or html_path in seen_paths:
                continue
            # Skip sub-component pages (power modules, fan modules, cables)
            if any(rx.search(chapter) for rx in SKIP_CHAPTER_PATTERNS):
                continue
            seen_paths.add(html_path)
            results.append({
                "html_path": html_path,
                "chapter":   chapter,
                "snippet":   hit.get("snippet", ""),
            })

    return results


# ---------------------------------------------------------------------------
# Deduplication helpers
# ---------------------------------------------------------------------------
def _text_fingerprint(text: str) -> str:
    normalised = re.sub(r"\s+", " ", text.strip().lower())
    return hashlib.md5(normalised.encode()).hexdigest()


def _is_install_procedure(text: str) -> bool:
    return any(rx.search(text) for rx in _INSTALL_RE)


# ---------------------------------------------------------------------------
# Step 3: Extract content from an HTML file
# seen_fingerprints: shared set for cross-page paragraph deduplication
# ---------------------------------------------------------------------------
def read_html(
    path: str,
    seen_fingerprints: set[str] | None = None,
    seen_table_fps: set[str] | None = None,
) -> dict | None:
    if seen_fingerprints is None:
        seen_fingerprints = set()
    if seen_table_fps is None:
        seen_table_fps = set()

    encodings = ["utf-8", "gbk", "gb18030", "big5", "latin-1"]
    html = None
    for enc in encodings:
        try:
            html = Path(path).read_text(encoding=enc)
            break
        except (UnicodeDecodeError, FileNotFoundError):
            continue
    if html is None:
        return None

    soup = BeautifulSoup(html, "html.parser")

    for tag in soup(["script", "style", "nav", "header", "footer"]):
        tag.decompose()

    # --- Heading ---
    heading = ""
    for tag_name in ("h1", "h2", "h3"):
        el = soup.find(tag_name)
        if el:
            heading = el.get_text(strip=True)
            break

    # --- Paragraphs: filter install procedures + noise + deduplicate ---
    paragraphs = []
    for p in soup.find_all("p"):
        text = p.get_text(separator=" ", strip=True)
        if len(text) <= 20:
            continue
        if _is_install_procedure(text):
            continue
        if _is_noise(text):
            continue
        fp = _text_fingerprint(text)
        if fp in seen_fingerprints:
            continue
        seen_fingerprints.add(fp)
        paragraphs.append(text)

    # --- Tables: deduplicate by first-row fingerprint ---
    tables = []
    for tbl in soup.find_all("table"):
        rows = []
        for tr in tbl.find_all("tr"):
            cells = [td.get_text(separator=" ", strip=True) for td in tr.find_all(["td", "th"])]
            if any(cells):
                rows.append(cells)
        if not rows:
            continue
        tbl_fp = _text_fingerprint(str(rows[0]))
        if tbl_fp in seen_table_fps:
            continue
        seen_table_fps.add(tbl_fp)
        tables.append(rows)

    # --- Images: resolve src to absolute disk paths ---
    images = []
    html_dir = Path(path).parent
    for img in soup.find_all("img"):
        src = img.get("src", "")
        if not src:
            continue
        # Strip CHM internal URI monikers (mk:@MSITStore:, ms-its:, its:)
        for prefix in ("mk:@msitstore:", "ms-its:", "its:"):
            if src.lower().startswith(prefix):
                src = src.split("::")[-1] if "::" in src else ""
                break
        if not src:
            continue

        # Skip UI icons and system resource images — only keep product figures
        src_lower = src.lower()
        if any(skip in src_lower for skip in (
            "public_sys-resources",   # note/notice/caution/warning icons
            "note_",
            "notice_",
            "caution_",
            "warning_",
            "tip_",
            "icon_",
            "bullet_",
            "arrow_",
        )):
            continue

        try:
            img_path = (html_dir / src).resolve()
        except Exception:
            continue
        if img_path.exists() and img_path.suffix.lower() in (".png", ".jpg", ".jpeg", ".gif", ".bmp"):
            images.append(str(img_path))

    if len(" ".join(paragraphs)) < MIN_TEXT_LENGTH and not tables and not images:
        return None

    return {
        "heading":    heading,
        "paragraphs": paragraphs,
        "tables":     tables,
        "images":     images,
    }


# ---------------------------------------------------------------------------
# Helper: table → markdown
# ---------------------------------------------------------------------------
def table_to_md(rows: list[list[str]]) -> str:
    if not rows:
        return ""
    col_count = max(len(r) for r in rows)
    padded = [r + [""] * (col_count - len(r)) for r in rows]
    widths = [max(len(padded[r][c]) for r in range(len(padded))) for c in range(col_count)]
    lines = []
    for i, row in enumerate(padded):
        line = "| " + " | ".join(cell.ljust(widths[c]) for c, cell in enumerate(row)) + " |"
        lines.append(line)
        if i == 0:
            sep = "| " + " | ".join("-" * widths[c] for c in range(col_count)) + " |"
            lines.append(sep)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helper: chapter numbering
# ---------------------------------------------------------------------------
def parse_chapter_start(s: str) -> list[int]:
    return [int(x) for x in s.split(".")]


def format_section_num(parts: list[int]) -> str:
    return ".".join(str(x) for x in parts)


# ---------------------------------------------------------------------------
# Step 4: Assemble intermediate markdown
# ---------------------------------------------------------------------------
def assemble_markdown(
    devices: list[str],
    device_content: dict[str, list[dict]],
    chapter_start: list[int],
    missing: list[str],
) -> str:
    lines = []
    section = chapter_start.copy()
    seen_fps: set[str] = set()

    # Series name from first device model (e.g. "CE8850-64CQ-EI" → "CE8850")
    first = devices[0] if devices else "NE8000"
    series = re.sub(r"[-_].*$", "", first)

    # --- Series intro ---
    lines.append(f"## {format_section_num(section)} {SECTION_TITLES['series_intro'].format(series=series)}")
    lines.append("")
    lines.append(
        f"The Huawei {series} series provides high-performance routing and switching "
        "platforms for backbone, metro core, and data centre interconnect networks. "
        "The following subsections present the hardware architecture and technical "
        "specifications of each device model included in this solution."
    )
    lines.append("")
    section[-1] += 1

    for model in devices:
        pages = device_content.get(model, [])
        device_num = format_section_num(section)

        lines.append(f"## {device_num} {SECTION_TITLES['bayface'].format(model=model)}")
        lines.append("")

        if not pages:
            lines.append(f"> ⚠️ **[CONTEÚDO NÃO ENCONTRADO — verificar manual: {model}]**")
            lines.append("")
            section[-1] += 1
            continue

        sub = section + [1]
        spec_tables: list[list[list[str]]] = []
        all_images: list[str] = []

        # ---- 3.x.1  Hardware components ----
        lines.append(f"### {format_section_num(sub)} {SECTION_TITLES['components'].format(model=model)}")
        lines.append("")

        for page in pages:
            content = page.get("_content")
            if not content:
                continue

            # Descriptive paragraphs
            for para in content.get("paragraphs", []):
                fp = _text_fingerprint(para)
                if fp in seen_fps:
                    continue
                seen_fps.add(fp)
                lines.append(para)
                lines.append("")

            # Non-spec tables inline
            for tbl in content.get("tables", []):
                if not tbl:
                    continue
                header_text = " ".join(tbl[0]).lower()
                is_spec = any(kw in header_text for kw in (
                    "item", "specification", "parameter",
                    "dimension", "weight", "power consumption",
                ))
                if is_spec:
                    spec_tables.append(tbl)
                else:
                    lines.append(table_to_md(tbl))
                    lines.append("")

            # Images inline after this page's content (dedup across pages)
            for img in content.get("images", []):
                if img not in all_images:
                    all_images.append(img)
                    lines.append(IMAGE_MARKER.format(path=img))
                    lines.append("")

        sub[-1] += 1

        # ---- 3.x.2  Technical specifications ----
        if spec_tables:
            lines.append(f"### {format_section_num(sub)} {SECTION_TITLES['specs'].format(model=model)}")
            lines.append("")
            for tbl in spec_tables:
                lines.append(table_to_md(tbl))
                lines.append("")

        lines.append("")
        section[-1] += 1

    # --- Missing content summary ---
    if missing:
        lines.append("---")
        lines.append("")
        lines.append("## ⚠️ Conteúdo em Falta")
        lines.append("")
        lines.append("Os seguintes dispositivos não tiveram conteúdo encontrado nos manuais indexados:")
        lines.append("")
        for m in missing:
            lines.append(f"- `{m}`")
        lines.append("")
        lines.append("Verifique se o manual CHM/HDX correspondente foi indexado com `build_index.py`.")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Step 5: Invoke render_docx.js
# ---------------------------------------------------------------------------
def render_docx(markdown_path: Path, out_dir: Path, chapter_start_str: str) -> Path:
    render_script = Path(__file__).parent / "render_docx.js"
    out_docx = out_dir / "hardware_chapter.docx"

    cmd = [
        "node", str(render_script),
        "--input",         str(markdown_path),
        "--output",        str(out_docx),
        "--chapter-start", chapter_start_str,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    if proc.returncode != 0:
        print(f"ERROR: render_docx.js failed:\n{proc.stderr}", file=sys.stderr)
        sys.exit(1)
    return out_docx


# ---------------------------------------------------------------------------
# Auto-unzip
# ---------------------------------------------------------------------------
def unzip_manuals(chm_path: Path) -> list[Path]:
    import zipfile

    zip_files = list(chm_path.glob("*.zip"))
    if not zip_files:
        return []

    extracted: list[Path] = []
    for zf_path in zip_files:
        print(f"  Found zip: {zf_path.name}")
        try:
            with zipfile.ZipFile(zf_path, "r") as zf:
                targets = [
                    m for m in zf.namelist()
                    if m.lower().endswith(".chm") or m.lower().endswith(".hdx")
                ]
                if not targets:
                    print(f"  [WARN] No .chm/.hdx found inside {zf_path.name}, skipping.")
                    continue
                for member in targets:
                    dest = chm_path / Path(member).name
                    if dest.exists():
                        print(f"  Already extracted: {dest.name} — skipping")
                    else:
                        print(f"  Extracting: {Path(member).name}")
                        dest.write_bytes(zf.read(member))
                        print(f"  → {dest}")
                    extracted.append(dest)
        except zipfile.BadZipFile:
            print(f"  [WARN] {zf_path.name} is not a valid zip, skipping.", file=sys.stderr)

    return extracted


# ---------------------------------------------------------------------------
# Auto-build index
# ---------------------------------------------------------------------------
def ensure_index(db_path: str, chm_dir: str | None, build_script: str | None) -> None:
    db = Path(db_path)

    if db.exists() and db.stat().st_size > 0:
        print(f"[0/4] Index found: {db}")
        return

    print(f"[0/4] index.db not found or empty at: {db}")

    if not chm_dir:
        print(
            "ERROR: index.db does not exist. Provide --chm-dir to enable auto-build.",
            file=sys.stderr,
        )
        sys.exit(1)

    if not build_script:
        print(
            "ERROR: --build-script not provided. Required for auto-build.",
            file=sys.stderr,
        )
        sys.exit(1)

    chm_path = Path(chm_dir)
    if not chm_path.is_dir():
        print(f"ERROR: --chm-dir is not a valid directory: {chm_dir}", file=sys.stderr)
        sys.exit(1)

    chm_files = list(chm_path.glob("*.chm")) + list(chm_path.glob("*.hdx"))
    zip_files  = list(chm_path.glob("*.zip"))

    if not chm_files and not zip_files:
        print(f"ERROR: No .chm, .hdx, or .zip files found in: {chm_dir}", file=sys.stderr)
        sys.exit(1)

    if zip_files:
        print(f"  Found {len(zip_files)} zip package(s) — extracting...")
        unzip_manuals(chm_path)
        chm_files = list(chm_path.glob("*.chm")) + list(chm_path.glob("*.hdx"))

    if not chm_files:
        print("ERROR: No .chm or .hdx files available after extracting zips.", file=sys.stderr)
        sys.exit(1)

    print(f"  {len(chm_files)} CHM/HDX file(s) ready for indexing")
    print(f"  Running build_index.py — this may take a few minutes...")

    proc = subprocess.run(
        [sys.executable, build_script, "--chm-dir", str(chm_path), "--db", db_path],
        text=True, encoding="utf-8",
    )
    if proc.returncode != 0:
        print(f"ERROR: build_index.py failed (exit {proc.returncode}).", file=sys.stderr)
        sys.exit(1)

    if not db.exists():
        print("ERROR: index.db was not created.", file=sys.stderr)
        sys.exit(1)

    print(f"  Index built successfully: {db}")


# ---------------------------------------------------------------------------
# Chapter-plan mode: assemble markdown directly from Agent-provided plan
# ---------------------------------------------------------------------------
def assemble_from_plan(plan: dict, chapter_start: list[int], out_dir: Path) -> str:
    """
    Consume a chapter_plan.json produced by the upstream Agent and assemble
    the intermediate markdown.

    Plan schema:
    {
      "model": "CE8850-64CQ-EI",
      "sections": [
        {
          "html_path": "...",
          "chapter":   "Hardware Description › Chassis › CE8850-64CQ-EI",
          "role":      "appearance | chassis_overview | specifications | sub_component",
          "section_title": "CE8850-64CQ-EI Bayface Design"   // optional override
        },
        ...
      ]
    }

    Role → assembly behaviour:
      appearance        → emitted first; images shown before tables
      chassis_overview  → main component description
      specifications    → content goes into a dedicated spec sub-section
      sub_component     → appended at end if present; can be omitted by Agent
    """
    model   = plan.get("model", "Unknown")
    sections = plan.get("sections", [])

    lines: list[str] = []
    section = chapter_start.copy()
    seen_fps: set[str] = set()
    seen_table_fps: set[str] = set()

    # Series name (e.g. "CE8850-64CQ-EI" → "CE8850")
    series = re.sub(r"[-_].*$", "", model)

    # --- Series intro ---
    lines.append(f"## {format_section_num(section)} {SECTION_TITLES['series_intro'].format(series=series)}")
    lines.append("")
    lines.append(
        f"The Huawei {series} series provides high-performance routing and switching "
        "platforms for backbone, metro core, and data centre interconnect networks. "
        "The following subsections present the hardware architecture and technical "
        "specifications of each device model included in this solution."
    )
    lines.append("")
    section[-1] += 1

    # Group sections by role
    def by_role(role: str) -> list[dict]:
        return [s for s in sections if s.get("role") == role]

    appearance_secs    = by_role("appearance")
    overview_secs      = by_role("chassis_overview")
    spec_secs          = by_role("specifications")
    subcomp_secs       = by_role("sub_component")

    # Device-level heading
    lines.append(f"## {format_section_num(section)} {SECTION_TITLES['bayface'].format(model=model)}")
    lines.append("")

    sub = section + [1]
    spec_tables: list[list[list[str]]] = []
    all_images: list[str] = []

    # ---- 3.x.1  Hardware components (appearance + overview) ----
    comp_title = overview_secs[0].get("section_title") if overview_secs else None
    comp_title = comp_title or SECTION_TITLES["components"].format(model=model)
    lines.append(f"### {format_section_num(sub)} {comp_title}")
    lines.append("")

    for sec in appearance_secs + overview_secs:
        content = read_html(
            sec["html_path"],
            seen_fingerprints=seen_fps,
            seen_table_fps=seen_table_fps,
        )
        if not content:
            continue
        is_appearance = sec.get("role") == "appearance"
        max_images = sec.get("max_images", 3 if is_appearance else 0)
        _emit_content(
            lines, content, spec_tables, all_images, seen_fps,
            max_images=max_images,
            images_first=is_appearance,
        )

    sub[-1] += 1

    # ---- 3.x.2  Technical specifications ----
    for sec in spec_secs:
        content = read_html(
            sec["html_path"],
            seen_fingerprints=seen_fps,
            seen_table_fps=seen_table_fps,
        )
        if not content:
            continue
        # All tables from spec pages go to spec_tables
        for tbl in content.get("tables", []):
            spec_tables.append(tbl)
        # Paragraphs and images still emitted inline
        for para in content.get("paragraphs", []):
            fp = _text_fingerprint(para)
            if fp not in seen_fps:
                seen_fps.add(fp)

    if spec_tables:
        spec_title = spec_secs[0].get("section_title") if spec_secs else None
        spec_title = spec_title or SECTION_TITLES["specs"].format(model=model)
        lines.append(f"### {format_section_num(sub)} {spec_title}")
        lines.append("")
        for tbl in spec_tables:
            lines.append(table_to_md(tbl))
            lines.append("")
        sub[-1] += 1

    # ---- 3.x.N  Sub-components (optional, only if Agent included them) ----
    for sec in subcomp_secs:
        content = read_html(
            sec["html_path"],
            seen_fingerprints=seen_fps,
            seen_table_fps=seen_table_fps,
        )
        if not content:
            continue
        title = sec.get("section_title") or sec.get("chapter", "").split("›")[-1].strip()
        lines.append(f"### {format_section_num(sub)} {title}")
        lines.append("")
        max_images = sec.get("max_images", 1)
        _emit_content(lines, content, [], [], seen_fps, max_images=max_images)
        sub[-1] += 1

    lines.append("")
    return "\n".join(lines)


def _emit_content(
    lines: list[str],
    content: dict,
    spec_tables: list,
    all_images: list[str],
    seen_fps: set[str],
    max_images: int = 99,
    images_first: bool = False,
) -> None:
    """Emit paragraphs, non-spec tables, and images from a page into lines.

    max_images:   cap on how many images to emit from this page (0 = none)
    images_first: if True, emit images before paragraphs/tables (appearance pages)
    """
    page_images: list[str] = []
    for img in content.get("images", []):
        if img not in all_images and len(page_images) < max_images:
            all_images.append(img)
            page_images.append(img)

    if images_first:
        for img in page_images:
            lines.append(IMAGE_MARKER.format(path=img))
            lines.append("")

    for para in content.get("paragraphs", []):
        fp = _text_fingerprint(para)
        if fp in seen_fps:
            continue
        seen_fps.add(fp)
        lines.append(para)
        lines.append("")

    for tbl in content.get("tables", []):
        if not tbl:
            continue
        header_text = " ".join(tbl[0]).lower()
        is_spec = any(kw in header_text for kw in (
            "item", "specification", "parameter",
            "dimension", "weight", "power consumption",
        ))
        if is_spec and spec_tables is not None:
            spec_tables.append(tbl)
        else:
            lines.append(table_to_md(tbl))
            lines.append("")

    if not images_first:
        for img in page_images:
            lines.append(IMAGE_MARKER.format(path=img))
            lines.append("")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Generate LLD hardware chapter from device list or chapter plan")

    # Input mode: either Agent-provided plan or legacy device-list mode
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument(
        "--chapter-plan",
        help="Path to chapter_plan.json produced by the upstream Agent (recommended)"
    )
    input_group.add_argument("--devices",      help="Comma-separated device model names (legacy mode)")
    input_group.add_argument("--devices-file", help="File with device models (legacy mode)")

    parser.add_argument("--out-dir",       required=True)
    parser.add_argument("--chapter-start", default="3.3")

    # Legacy mode only
    parser.add_argument("--db",            help="Path to index.db (legacy mode)")
    parser.add_argument("--search-script", help="Path to search.py (legacy mode)")
    parser.add_argument("--top-k",         type=int, default=5)
    parser.add_argument("--chm-dir",       help="For auto-build (legacy mode)")
    parser.add_argument("--build-script",  help="For auto-build (legacy mode)")
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    chapter_parts = parse_chapter_start(args.chapter_start)

    # ----------------------------------------------------------------
    # Mode A: chapter-plan (Agent-driven)
    # ----------------------------------------------------------------
    if args.chapter_plan:
        plan_path = Path(args.chapter_plan)
        if not plan_path.exists():
            print(f"ERROR: chapter plan not found: {plan_path}", file=sys.stderr)
            sys.exit(1)

        plan = json.loads(plan_path.read_text(encoding="utf-8"))
        model = plan.get("model", "Unknown")
        print(f"[plan] Model: {model}")
        print(f"[plan] Sections: {len(plan.get('sections', []))}")

        print("[1/2] Assembling markdown from plan...")
        markdown = assemble_from_plan(plan, chapter_parts, out_dir)

    # ----------------------------------------------------------------
    # Mode B: legacy device-list (auto search + filter)
    # ----------------------------------------------------------------
    else:
        if not args.db or not args.search_script:
            print("ERROR: --db and --search-script are required in legacy mode.", file=sys.stderr)
            sys.exit(1)

        ensure_index(args.db, args.chm_dir, args.build_script)

        devices = parse_devices(args)
        print(f"[1/4] Devices: {devices}")

        print(f"[2/4] Searching CHM index...")
        device_content: dict[str, list[dict]] = {}
        missing: list[str] = []
        global_seen_fps: set[str] = set()
        global_seen_table_fps: set[str] = set()

        for model in devices:
            print(f"  Searching: {model}")
            hits = search_device(model, args.db, args.search_script, args.top_k)
            pages = []
            for hit in hits:
                content = read_html(
                    hit["html_path"],
                    seen_fingerprints=global_seen_fps,
                    seen_table_fps=global_seen_table_fps,
                )
                if content:
                    hit["_content"] = content
                    pages.append(hit)
            device_content[model] = pages
            if not pages:
                missing.append(model)
                print(f"  [WARN] No content found for: {model}", file=sys.stderr)
            else:
                img_count = sum(len(p["_content"].get("images", [])) for p in pages)
                print(f"  → {len(pages)} pages, {img_count} image(s)")

        print(f"[3/4] Assembling markdown...")
        markdown = assemble_markdown(devices, device_content, chapter_parts, missing)

    # ----------------------------------------------------------------
    # Common: write markdown + render docx
    # ----------------------------------------------------------------
    md_path = out_dir / "hardware_chapter.md"
    md_path.write_text(markdown, encoding="utf-8")
    print(f"  → Written: {md_path}")

    print("Rendering .docx...")
    docx_path = render_docx(md_path, out_dir, args.chapter_start)
    print(f"  → Output: {docx_path}")
    print("\nDone.")


if __name__ == "__main__":
    main()