"""
parse_device_list.py
--------------------
Reads an Excel file containing a device list sheet and extracts unique
network device models, skipping non-network hardware (servers, appliances).

Usage:
    python parse_device_list.py \
        --excel path/to/devices.xlsx \
        --out device_list.json \
        [--sheet "Sheet1"] \
        [--model-col "Device Model"] \
        [--role-col "Device Role"]

Output device_list.json:
{
  "source": "devices.xlsx",
  "devices": [
    {
      "model": "CE8850-64CQ-EI",
      "role": "Spine",
      "qty": 2,
      "locations": ["DF"],
      "description": "CE8850-64CQ-EI Switch..."
    },
    ...
  ],
  "skipped": [
    { "model": "2288H V6(128GB)", "reason": "server/appliance" }
  ]
}
"""

import sys
import json
import argparse
import re
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

try:
    import openpyxl
except ImportError:
    print("ERROR: openpyxl not installed. Run: pip install openpyxl", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Non-network device patterns — these are skipped for CHM hardware lookup
# (servers, management appliances, storage)
# ---------------------------------------------------------------------------
NON_NETWORK_PATTERNS = [
    r"2288H",           # xFusion / Huawei server
    r"2488H",
    r"\bserver\b",
    r"appliance",
    r"storage",
    r"OceanStor",
    r"FusionServer",
    r"RH\d{4}",         # legacy Huawei rack server
]
_NON_NETWORK_RE = [re.compile(p, re.IGNORECASE) for p in NON_NETWORK_PATTERNS]


def is_non_network(model: str, role: str = "") -> bool:
    text = f"{model} {role}"
    return any(rx.search(text) for rx in _NON_NETWORK_RE)


# ---------------------------------------------------------------------------
# Find the device list sheet and header row
# ---------------------------------------------------------------------------
def find_header_row(ws, model_col_name: str) -> tuple[int | None, dict[str, int]]:
    """
    Scan rows to find the header row containing model_col_name.
    Returns (row_index, {col_name: col_index}) or (None, {}).
    """
    for row_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
        row_vals = [str(v).strip() if v is not None else "" for v in row]
        # Look for the model column header (case-insensitive partial match)
        for ci, val in enumerate(row_vals):
            if model_col_name.lower() in val.lower():
                # Build column map from this header row
                col_map = {v: i for i, v in enumerate(row_vals) if v}
                return row_idx, col_map
    return None, {}


def fuzzy_col(col_map: dict[str, int], candidates: list[str]) -> int | None:
    """Find column index by trying multiple candidate names (case-insensitive)."""
    for name in candidates:
        for key, idx in col_map.items():
            if name.lower() in key.lower():
                return idx
    return None


# ---------------------------------------------------------------------------
# Main extraction logic
# ---------------------------------------------------------------------------
def extract_devices(
    excel_path: str,
    sheet_name: str | None,
    model_col_name: str,
    role_col_name: str,
) -> tuple[list[dict], list[dict]]:
    """
    Returns (devices, skipped).
    devices: list of {model, role, qty, locations, description}
    skipped: list of {model, reason}
    """
    wb = openpyxl.load_workbook(excel_path, data_only=True)

    # Find the right sheet
    if sheet_name:
        if sheet_name not in wb.sheetnames:
            raise ValueError(f"Sheet '{sheet_name}' not found. Available: {wb.sheetnames}")
        ws = wb[sheet_name]
    else:
        # Auto-detect: prefer sheets with "device" in the name
        target = None
        for name in wb.sheetnames:
            if "device" in name.lower():
                target = name
                break
        ws = wb[target or wb.sheetnames[0]]
        print(f"  Using sheet: {ws.title}")

    # Find header row
    header_row_idx, col_map = find_header_row(ws, model_col_name)
    if header_row_idx is None:
        raise ValueError(
            f"Could not find header row with column '{model_col_name}'. "
            f"Check --model-col argument."
        )
    print(f"  Header row: {header_row_idx}, columns: {list(col_map.keys())}")

    # Map columns
    model_ci = fuzzy_col(col_map, [model_col_name, "model", "device model", "device"])
    role_ci   = fuzzy_col(col_map, [role_col_name, "role", "device role", "function"])
    qty_ci    = fuzzy_col(col_map, ["qty", "quantity", "total qty", "count"])
    loc_ci    = fuzzy_col(col_map, ["location", "site", "dc", "datacenter"])
    desc_ci   = fuzzy_col(col_map, ["description", "desc", "detail"])

    if model_ci is None:
        raise ValueError(f"Could not find model column. col_map: {col_map}")

    # Accumulate by model
    seen: dict[str, dict] = {}   # model → aggregated entry
    skipped: list[dict]   = []

    rows = list(ws.iter_rows(min_row=header_row_idx + 1, values_only=True))
    for row in rows:
        if not any(v for v in row):
            continue  # skip blank rows

        def cell(ci):
            if ci is None or ci >= len(row):
                return ""
            v = row[ci]
            return str(v).strip() if v is not None else ""

        model = cell(model_ci)
        if not model:
            continue

        role  = cell(role_ci)
        qty   = cell(qty_ci)
        loc   = cell(loc_ci)
        desc  = cell(desc_ci)

        # Parse qty
        try:
            qty_int = int(float(qty)) if qty else 1
        except ValueError:
            qty_int = 1

        # Skip non-network devices
        if is_non_network(model, role):
            if not any(s["model"] == model for s in skipped):
                skipped.append({"model": model, "reason": "server/appliance — no CHM lookup"})
            continue

        # Aggregate by model
        if model not in seen:
            seen[model] = {
                "model":       model,
                "role":        role,
                "qty":         qty_int,
                "locations":   [loc] if loc else [],
                "description": desc,
            }
        else:
            seen[model]["qty"] += qty_int
            if loc and loc not in seen[model]["locations"]:
                seen[model]["locations"].append(loc)
            # Keep first non-empty description
            if not seen[model]["description"] and desc:
                seen[model]["description"] = desc

    devices = list(seen.values())
    return devices, skipped


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Extract device list from Excel for LLD generation")
    parser.add_argument("--excel",     required=True, help="Path to Excel file")
    parser.add_argument("--out",       required=True, help="Output path for device_list.json")
    parser.add_argument("--sheet",     default=None,  help="Sheet name (auto-detect if omitted)")
    parser.add_argument("--model-col", default="Device Model", help="Header name for model column")
    parser.add_argument("--role-col",  default="Device Role",  help="Header name for role column")
    args = parser.parse_args()

    print(f"Parsing: {args.excel}")

    devices, skipped = extract_devices(
        args.excel, args.sheet, args.model_col, args.role_col
    )

    print(f"  → {len(devices)} network device model(s) found")
    for d in devices:
        print(f"     {d['model']:30s}  role={d['role']:20s}  qty={d['qty']}")
    if skipped:
        print(f"  → {len(skipped)} skipped (non-network):")
        for s in skipped:
            print(f"     {s['model']}  ({s['reason']})")

    output = {
        "source":  str(Path(args.excel).name),
        "devices": devices,
        "skipped": skipped,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  → Written: {out_path}")


if __name__ == "__main__":
    main()