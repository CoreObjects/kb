"""
explore_chapters.py
-------------------
Phase 1 of the Agent-driven hardware chapter generation pipeline.

This script performs broad searches against the CHM index and returns a
structured list of candidate chapters for a given device model.  It does NOT
classify or filter — that decision is left to the upstream Agent.

The upstream Agent reads candidates.json, classifies each chapter by role
(appearance / chassis_overview / specifications / sub_component / irrelevant),
and writes chapter_plan.json which is consumed by gen_hardware_chapter.py.

Usage:
    python explore_chapters.py \
        --model "CE8850-64CQ-EI" \
        --db manuals/index.db \
        --search-script skills/chm-search-skill/scripts/search.py \
        --out candidates.json \
        [--top-k 10]
"""

import sys
import json
import argparse
import subprocess
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

# ---------------------------------------------------------------------------
# Broad exploration queries — intentionally wide to surface all relevant
# chapter types without pre-judging what the manual structure looks like.
# The upstream Agent will do the classification.
# ---------------------------------------------------------------------------
EXPLORE_QUERIES = [
    "{model}",
    "{model} hardware",
    "{model} appearance",
    "{model} specifications",
    "{model} panel",
    "{model} description",
]


def search(query: str, db: str, script: str, top_k: int) -> list[dict]:
    cmd = [sys.executable, script, "--db", db, "-q", query, "--json"]
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8", timeout=30
        )
    except subprocess.TimeoutExpired:
        print(f"  [WARN] timeout: {query!r}", file=sys.stderr)
        return []
    except FileNotFoundError:
        print(f"ERROR: search script not found: {script}", file=sys.stderr)
        sys.exit(1)

    if proc.returncode != 0:
        return []

    try:
        return json.loads(proc.stdout)[:top_k]
    except json.JSONDecodeError:
        return []


def main():
    parser = argparse.ArgumentParser(
        description="Explore CHM index and output candidate chapters for Agent classification"
    )
    parser.add_argument("--model",         required=True, help="Device model name e.g. CE8850-64CQ-EI")
    parser.add_argument("--db",            required=True, help="Path to index.db")
    parser.add_argument("--search-script", required=True, help="Path to search.py")
    parser.add_argument("--out",           required=True, help="Output path for candidates.json")
    parser.add_argument("--top-k",         type=int, default=10, help="Results per query (default 10)")
    args = parser.parse_args()

    print(f"Exploring chapters for: {args.model}")

    seen_paths: set[str] = set()
    candidates: list[dict] = []

    for template in EXPLORE_QUERIES:
        query = template.format(model=args.model)
        print(f"  Query: {query!r}")
        hits = search(query, args.db, args.search_script, args.top_k)

        for hit in hits:
            html_path = hit.get("html_path", "")
            if not html_path or html_path in seen_paths:
                continue
            seen_paths.add(html_path)
            candidates.append({
                "html_path": html_path,
                "chapter":   hit.get("chapter", ""),
                "snippet":   hit.get("snippet", ""),
                "chm":       hit.get("chm", ""),
            })

    print(f"  → {len(candidates)} unique candidates found")

    output = {
        "model":      args.model,
        "candidates": candidates,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"  → Written: {out_path}")


if __name__ == "__main__":
    main()