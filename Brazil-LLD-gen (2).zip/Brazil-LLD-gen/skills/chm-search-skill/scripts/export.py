#!/usr/bin/env python3
"""Convert one CHM HTML page to .docx via pandoc, with tab normalization.

Usage:
    python export.py --html <html_path> --out <docx_path> [--reference-doc <template.docx>]
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

# Force UTF-8 on stdout/stderr so Chinese chars print correctly in Windows cmd
# (which defaults to GBK / CP936 and chokes on chars outside its table).
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, TypeError):
        pass

try:
    from bs4 import BeautifulSoup
except ImportError:
    print("ERROR: please run `pip install beautifulsoup4`", file=sys.stderr)
    sys.exit(1)

# Local module — Python adds the script's dir to sys.path automatically
# when run as `python scripts/export.py ...`
sys.path.insert(0, str(Path(__file__).resolve().parent))
from html_clean import (  # noqa: E402
    absolutize_img_srcs,
    looks_like_stub,
    prune_dead_links,
    strip_boilerplate,
)


ENCODINGS = ("utf-8", "gbk", "gb18030", "big5", "latin-1")


def read_text(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ENCODINGS:
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")


def unhide(el) -> None:
    """Strip attributes/styles that hide an element."""
    if el.has_attr("hidden"):
        del el["hidden"]
    if el.has_attr("style"):
        new = re.sub(r"display\s*:\s*none\s*;?", "", el["style"], flags=re.I)
        new = re.sub(r"visibility\s*:\s*hidden\s*;?", "", new, flags=re.I)
        if new.strip():
            el["style"] = new
        else:
            del el["style"]
    if el.has_attr("class"):
        kept = [c for c in el["class"] if c.lower() not in ("hide", "hidden", "d-none")]
        if kept:
            el["class"] = kept
        else:
            del el["class"]


def normalize_tabs(soup: BeautifulSoup) -> BeautifulSoup:
    """Rewrite tab structures so all tab content appears as flat H2 sections."""

    # 1) ARIA tabs
    for tablist in soup.find_all(attrs={"role": "tablist"}):
        panel_by_id = {
            p.get("id"): p
            for p in soup.find_all(attrs={"role": "tabpanel"})
            if p.get("id")
        }
        for tab in tablist.find_all(attrs={"role": "tab"}):
            label = tab.get_text(strip=True)
            controls = tab.get("aria-controls")
            panel = panel_by_id.get(controls) if controls else None
            if panel and label:
                h = soup.new_tag("h2")
                h.string = label
                panel.insert_before(h)
                unhide(panel)
        tablist.decompose()

    # 2) Class-name-based tabs (Bootstrap, vendor styles, Huawei-ish, etc.)
    nav_selectors = [
        ".nav-tabs", ".tab-nav", ".tabs-nav", ".tab-head", ".tab-header",
        ".tab-list", "ul.tabs", "ul.tab", ".tabs-header",
    ]
    for sel in nav_selectors:
        for nav in soup.select(sel):
            for tab in nav.find_all(["li", "a", "button"]):
                label = tab.get_text(strip=True)
                if not label:
                    continue
                target_id = None
                a = tab if tab.name == "a" else tab.find("a")
                if a and a.get("href", "").startswith("#"):
                    target_id = a["href"][1:]
                if not target_id:
                    target_id = (
                        tab.get("data-target") or tab.get("aria-controls") or ""
                    ).lstrip("#")
                if not target_id:
                    continue
                panel = soup.find(id=target_id)
                if panel:
                    h = soup.new_tag("h2")
                    h.string = label
                    panel.insert_before(h)
                    unhide(panel)
            nav.decompose()

    # 3) Safety net: un-hide any remaining display:none container with substantial text
    for el in soup.find_all(style=re.compile(r"display\s*:\s*none", re.I)):
        if len(el.get_text(strip=True)) > 30:
            unhide(el)

    return soup


def find_pandoc() -> Optional[str]:
    """Locate the pandoc executable. Returns full path or None.

    Search order mirrors find_7z() in build_index.py:
      1. PATH (`shutil.which`)
      2. `%LOCALAPPDATA%\\Pandoc\\pandoc.exe`   (winget user-scope install,
         which doesn't always update PATH for already-running shells)
      3. `C:\\Program Files\\Pandoc\\pandoc.exe`        (machine-scope MSI)
      4. `C:\\Program Files (x86)\\Pandoc\\pandoc.exe`  (rare 32-bit install)
    """
    found = shutil.which("pandoc") or shutil.which("pandoc.exe")
    if found:
        return found
    candidates = []
    local_app = os.environ.get("LOCALAPPDATA")
    if local_app:
        candidates.append(Path(local_app) / "Pandoc" / "pandoc.exe")
    candidates.extend([
        Path(r"C:\Program Files\Pandoc\pandoc.exe"),
        Path(r"C:\Program Files (x86)\Pandoc\pandoc.exe"),
    ])
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def html_to_docx(
    html_path: Path,
    docx_path: Path,
    reference_doc: Optional[Path] = None,
    force: bool = False,
) -> None:
    pandoc = find_pandoc()
    if pandoc is None:
        print(
            "ERROR: pandoc not found in PATH or default install locations\n"
            "       (%LOCALAPPDATA%\\Pandoc, C:\\Program Files\\Pandoc, etc.).\n"
            "Install: winget install --id JohnMacFarlane.Pandoc",
            file=sys.stderr,
        )
        sys.exit(2)

    if not html_path.exists():
        print(f"ERROR: HTML not found: {html_path}", file=sys.stderr)
        sys.exit(1)

    text = read_text(html_path)
    soup = BeautifulSoup(text, "html.parser")

    # 1. Strip non-content elements outright.
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    # 2. Strip nav / footer / copyright boilerplate.
    n_strip = strip_boilerplate(soup)

    # 3. Refuse to convert link-only navigation hub pages (unless --force).
    if not force and looks_like_stub(soup):
        print(
            f"ERROR: {html_path.name} appears to be a navigation/index page\n"
            f"       (mostly links, no substantive paragraphs). Refusing to export.\n"
            f"Hint: pick a content page from the search results, or pass --force\n"
            f"      to export this page anyway.",
            file=sys.stderr,
        )
        sys.exit(3)

    # 4. Rewrite <img src> to absolute file:// URIs so pandoc can find images
    #    regardless of how deeply they're nested under the decompile root.
    n_img_fixed, n_img_removed = absolutize_img_srcs(soup, html_path)

    # 5. Flatten tab containers into sequential H2 sections.
    normalize_tabs(soup)

    # 6. Unwrap cross-topic <a> links whose targets won't resolve in this
    #    standalone .docx (preserves the visible text, drops the dead link).
    n_links_pruned = prune_dead_links(soup)

    print(
        f"  cleaned: -{n_strip} boilerplate, "
        f"{n_img_fixed} image(s) resolved, "
        f"{n_img_removed} broken image(s) dropped, "
        f"{n_links_pruned} dead link(s) unwrapped"
    )

    # Write normalized HTML next to the original so any remaining relative
    # paths (CSS, fonts) still resolve.
    tmp = html_path.parent / f".{html_path.stem}.normalized.html"
    try:
        tmp.write_text(str(soup), encoding="utf-8")
        cmd = [
            pandoc, str(tmp),
            "-o", str(docx_path),
            "-f", "html", "-t", "docx",
            "--resource-path", str(html_path.parent),
        ]
        if reference_doc:
            cmd += ["--reference-doc", str(reference_doc)]
        subprocess.run(cmd, check=True)
    finally:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--html", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--reference-doc")
    ap.add_argument(
        "--force", action="store_true",
        help="Export even if the page looks like a navigation/index stub.",
    )
    args = ap.parse_args()

    html_to_docx(
        Path(args.html),
        Path(args.out),
        Path(args.reference_doc) if args.reference_doc else None,
        force=args.force,
    )
    print(f"Wrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
