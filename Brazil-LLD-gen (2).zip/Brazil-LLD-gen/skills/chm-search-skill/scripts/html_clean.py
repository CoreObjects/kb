"""Shared HTML cleanup helpers used by both build_index.py and export.py.

Three responsibilities, all conservative (prefer false-negatives over
false-positives):

1. strip_boilerplate(soup)     — remove nav / footer / copyright junk
2. looks_like_stub(soup)       — detect link-only navigation-hub pages
3. absolutize_img_srcs(soup, html_path)
                                — rewrite <img src> to absolute file URIs so
                                  pandoc can resolve images regardless of
                                  --resource-path coverage
"""
from __future__ import annotations

import re
from pathlib import Path

# ---------------------------------------------------------------------------
# 1. Boilerplate stripping
# ---------------------------------------------------------------------------

# Selectors for elements that are almost never primary content.
# Conservative rule below also requires the element's visible text to be
# under 1000 chars before we delete it — guards against pages that
# accidentally use semantic tags (<header>) for real content.
BOILERPLATE_SELECTORS = (
    "header", "footer", "nav",
    ".header", ".footer", ".navigation", ".nav",
    ".breadcrumb", ".breadcrumbs", ".crumb", ".crumbs",
    ".toolbar", ".action-bar", ".actions",
    ".page-nav", "nav.page-actions", ".page-actions", ".page-tools",
    ".copyright", ".company-info", ".legal", ".disclaimer",
    "#header", "#footer", "#nav", "#navigation",
    "#breadcrumb", "#breadcrumbs", "#crumbs",
    "#toolbar", "#copyright",
)

# Only applied to small elements (< 200 chars). Catches legacy pages that
# don't use semantic tags or class names but contain telltale phrases.
BOILERPLATE_TEXT_RE = re.compile(
    r"(?:"
    r"上一级页面|下一级页面|返回首页|返回上一页|返回顶部|"
    r"打印本页|打印页面|分享到|收藏本页|加入收藏|"
    r"版权所有|All\s+rights\s+reserved|Copyright\s*©|©\s*\d{4}"
    r")",
    re.IGNORECASE,
)


def strip_boilerplate(soup) -> int:
    """Remove navigation / footer / copyright noise. Returns count removed."""
    removed = 0

    # Pass 1: structural selectors. Skip elements that look too long to be
    # boilerplate (defensive against semantic-tag misuse).
    for sel in BOILERPLATE_SELECTORS:
        for el in soup.select(sel):
            text_len = len(el.get_text(strip=True))
            if text_len < 1000:
                el.decompose()
                removed += 1

    # Pass 2: small elements with telltale boilerplate phrases.
    for tag_name in ("div", "p", "span", "a", "li"):
        for el in list(soup.find_all(tag_name)):
            text = el.get_text(" ", strip=True)
            if not text or len(text) > 200:
                continue
            if BOILERPLATE_TEXT_RE.search(text):
                el.decompose()
                removed += 1

    return removed


# ---------------------------------------------------------------------------
# 2. Stub-page detection
# ---------------------------------------------------------------------------

def looks_like_stub(soup) -> bool:
    """True if the page is mostly a list of links with no real content.

    Conservative: requires multiple corroborating signals before flagging.
    Run this AFTER strip_boilerplate so footers / breadcrumbs don't bias
    the link-ratio calculation.
    """
    text = soup.get_text(" ", strip=True)
    if not text or len(text) < 30:
        return True

    anchors = soup.find_all("a")
    paragraphs = soup.find_all("p")

    link_text = " ".join(a.get_text(" ", strip=True) for a in anchors)
    link_ratio = len(link_text) / len(text) if text else 0.0

    # Substantive paragraph = a <p> with > 30 chars of plain text.
    substantive = sum(1 for p in paragraphs if len(p.get_text(strip=True)) > 30)

    # Rule A: very link-heavy AND almost no paragraphs.
    if link_ratio > 0.7 and substantive < 2:
        return True

    # Rule B: zero substantive paragraphs and a non-trivial link list.
    if substantive == 0 and len(anchors) >= 3:
        return True

    return False


# ---------------------------------------------------------------------------
# 3. Image src absolutization
# ---------------------------------------------------------------------------

_CHM_URI_PREFIXES = ("mk:@msitstore:", "ms-its:", "its:")


def _parse_chm_uri(src: str):
    """If src is a CHM internal URI, return the inner archive path; else None.

    CHM HTML routinely uses Microsoft's legacy URL monikers to point into
    the .chm archive itself:
        mk:@MSITStore:[name.chm]::/path/inside.png
        ms-its:[name.chm]::/path/inside.png
        its:[name.chm]::/path/inside.png
    After 7-Zip extraction those inner paths map directly to files under
    the decompile root, so we just need to discard the scheme + .chm name
    and keep the part after `::`.
    """
    lower = src.lower()
    for prefix in _CHM_URI_PREFIXES:
        if lower.startswith(prefix):
            rest = src[len(prefix):]
            if "::" in rest:
                _, inner = rest.split("::", 1)
                return inner
            # Malformed but salvageable: no :: separator at all.
            return rest
    return None


def prune_dead_links(soup) -> int:
    """Unwrap <a> tags whose targets won't resolve in a standalone .docx,
    so the link text survives but no broken hyperlink remains.

    Kept (left clickable in the docx):
      - External web/mailto links: http(s)://… , mailto:…
      - Real in-page anchors:      #some_section_id

    Unwrapped (replaced with plain text content):
      - Cross-topic relative file links like  gx/gx_hd_100GE_optical_module.html
        (point to other CHM topics that aren't part of this single .docx)
      - Bare placeholders like  href="#"  with JS handlers
      - Empty / whitespace-only href

    `<a name="…"></a>` destination anchors (no href attribute) are left alone.

    Returns the number of <a> elements unwrapped.
    """
    pruned = 0
    for a in list(soup.find_all("a")):
        if not a.has_attr("href"):
            continue  # destination anchor, not a link
        href = (a.get("href") or "").strip()
        if not href:
            a.unwrap()
            pruned += 1
            continue
        if href.startswith(("http://", "https://", "mailto:")):
            continue
        if href.startswith("#") and len(href) > 1:
            continue  # real in-page anchor
        a.unwrap()
        pruned += 1
    return pruned


def absolutize_img_srcs(soup, html_path: Path) -> tuple[int, int]:
    """Rewrite each <img src> to an absolute on-disk path so pandoc can embed
    the image into the .docx.

    Handles four CHM-typical src conventions:
      1.  images/fan.png        — relative to current HTML
      2.  ../res/fan.png        — relative parent
      3.  /images/fan.png       — root-relative WITHIN the CHM (resolved
                                 against the decompile root, not the
                                 on-disk filesystem root)
      4.  mk:@MSITStore:foo.chm::/images/fan.png
          ms-its:foo.chm::/images/fan.png
          its:foo.chm::/images/fan.png
                                — Microsoft CHM-internal URI moniker;
                                 the `::`-delimited inner path is what
                                 ends up on disk after 7-Zip extraction

    Also tolerates Windows-style backslashes in src.

    Uses plain absolute paths (not file:// URIs) — more reliable across
    pandoc versions and avoids URI-encoding quirks with non-ASCII paths.

    Drops <img> elements whose src cannot be resolved on disk and prints
    the unresolved src strings for diagnostics.

    Returns (fixed, removed).
    """
    base = html_path.parent

    # Walk up to find the decompile root (any ancestor whose name ends with
    # `_decompiled`). Used for case 3 (root-relative paths).
    decompile_root = base
    cur = base
    while cur != cur.parent:
        if cur.name.lower().endswith("_decompiled"):
            decompile_root = cur
            break
        cur = cur.parent

    fixed = 0
    removed = 0
    misses: list[str] = []

    for img in list(soup.find_all("img")):
        src = (img.get("src") or "").strip()
        if not src:
            img.decompose()
            removed += 1
            continue

        # CHM internal URI? Strip the scheme and resolve under decompile root.
        chm_inner = _parse_chm_uri(src)
        if chm_inner is not None:
            clean = (chm_inner.split("?", 1)[0].split("#", 1)[0]
                              .replace("\\", "/").lstrip("/").strip())
            if not clean:
                img.decompose()
                removed += 1
                continue
            candidates = [decompile_root / clean]
        # Already absolute web/data URI — leave alone.
        elif src.startswith(("http://", "https://", "data:", "file:")):
            continue
        else:
            # Normalize: strip query/fragment, convert backslashes.
            clean = src.split("?", 1)[0].split("#", 1)[0].replace("\\", "/").strip()
            if not clean:
                img.decompose()
                removed += 1
                continue

            # Build resolution candidates in priority order.
            if clean.startswith("/"):
                # Root-relative within the CHM.
                candidates = [decompile_root / clean.lstrip("/")]
            else:
                candidates = [base / clean]
                # Fallback: try resolving against the decompile root in case
                # the HTML uses a path convention we didn't anticipate.
                if decompile_root != base:
                    candidates.append(decompile_root / clean)

        target = None
        for cand in candidates:
            try:
                p = cand.resolve()
            except (OSError, ValueError):
                continue
            if p.exists() and p.is_file():
                target = p
                break

        if target is None:
            misses.append(src)
            img.decompose()
            removed += 1
            continue

        # Plain forward-slash absolute path is more portable across pandoc
        # versions than a file:// URI, especially with non-ASCII chars.
        img["src"] = str(target).replace("\\", "/")
        fixed += 1

    if misses:
        sample = misses[:5]
        more = f" ... (+{len(misses) - 5} more)" if len(misses) > 5 else ""
        print(f"  unresolved image src(s): {sample}{more}")

    return fixed, removed
