#!/usr/bin/env python3
"""Build a SQLite FTS5 index over decompiled CHM and HDX (Huawei HedEx) files.

Both formats are extracted with 7-Zip (HDX is a zip-based container; CHM is
ITSF). Both contain a `.hhc` sitemap-format TOC inside the decompiled tree,
so the same parsing pipeline handles them.

Usage:
    python build_index.py --chm-dir <dir> [--out-dir <dir>] [--db <path>] [--rebuild]
"""
from __future__ import annotations

import argparse
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

# Force UTF-8 on stdout/stderr so Chinese chars print correctly in Windows cmd
# (which defaults to GBK / CP936 and chokes on chars outside its table).
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, TypeError):
        pass

try:
    from bs4 import BeautifulSoup
except ImportError:
    print("ERROR: please run `pip install beautifulsoup4`", file=sys.stderr)
    sys.exit(1)

# Local module — Python adds the script's dir to sys.path automatically
# when run as `python scripts/build_index.py ...`
sys.path.insert(0, str(Path(__file__).resolve().parent))
from html_clean import strip_boilerplate, looks_like_stub  # noqa: E402


ENCODINGS = ("utf-8", "gbk", "gb18030", "big5", "latin-1")


def read_text(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ENCODINGS:
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace")


def find_7z() -> Optional[str]:
    """Locate a 7-Zip executable. Returns full path or None."""
    found = shutil.which("7z") or shutil.which("7z.exe")
    if found:
        return found
    for candidate in (
        r"C:\Program Files\7-Zip\7z.exe",
        r"C:\Program Files (x86)\7-Zip\7z.exe",
    ):
        if Path(candidate).exists():
            return candidate
    return None


def _extract_with_7zip(sevenzip: str, chm: Path, out_dir: Path) -> bool:
    chm_abs = str(chm.resolve())
    # -y: assume Yes; -bso0/-bsp0: silence stdout/progress (we still get stderr on error)
    cmd = [sevenzip, "x", chm_abs, f"-o{out_dir}", "-y", "-bso0", "-bsp0"]
    print(f"  cmd: 7z x \"{chm.name}\" -o\"{out_dir}\"")
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=600,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f"  7z error: {e}", file=sys.stderr)
        return False

    if result.returncode != 0:
        print(f"  7z rc={result.returncode}")
        if result.stderr.strip():
            print(f"  stderr: {result.stderr.strip()[:500]}")
        return False

    files = list(out_dir.rglob("*"))
    if not files:
        print(f"  WARNING: 7z reported success but produced no files in {out_dir}")
        return False
    print(f"  extracted {len(files)} entries")
    return True


def _extract_with_hhexe(chm: Path, out_dir: Path) -> bool:
    """Last-resort fallback. hh.exe -decompile is undocumented, deprecated,
    and silently no-ops on many modern Windows installs (HTML Help has been
    deprecated since 2008; IE retired in 2022).

    Workaround: chdir into out_dir and pass '.' as output, since hh.exe
    sometimes ignores absolute output paths and writes to cwd anyway.
    """
    chm_abs = str(chm.resolve())
    cmd = ["hh.exe", "-decompile", ".", chm_abs]
    print(f"  cmd (fallback): hh.exe -decompile . \"{chm_abs}\"  (cwd={out_dir})")
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=600,
            cwd=str(out_dir),
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f"  hh.exe error: {e}", file=sys.stderr)
        return False

    print(f"  hh.exe rc={result.returncode}")
    if result.stdout.strip():
        print(f"  stdout: {result.stdout.strip()[:500]}")
    if result.stderr.strip():
        print(f"  stderr: {result.stderr.strip()[:500]}")

    # hh.exe forks a worker and the parent may exit before files land. Poll up to 30s.
    deadline = 30
    waited = 0.0
    while waited < deadline:
        if any(out_dir.rglob("*")):
            time.sleep(1)  # grace period
            files = list(out_dir.rglob("*"))
            print(f"  decompiled {len(files)} entries into {out_dir}")
            return True
        time.sleep(0.5)
        waited += 0.5

    print(f"  WARNING: no files appeared in {out_dir} after {deadline}s")
    print(f"  hh.exe is unreliable on modern Windows — install 7-Zip:")
    print(f"    winget install --id 7zip.7zip")
    return False


def decompile_chm(chm: Path, out_dir: Path) -> bool:
    """Extract a CHM into out_dir. Prefer 7-Zip; fall back to hh.exe."""
    out_dir.mkdir(parents=True, exist_ok=True)

    sevenzip = find_7z()
    if sevenzip:
        return _extract_with_7zip(sevenzip, chm, out_dir)

    print("  WARNING: 7-Zip not found in PATH or default install locations.")
    print("  Falling back to hh.exe (often broken on modern Windows).")
    print("  Recommended:  winget install --id 7zip.7zip")
    return _extract_with_hhexe(chm, out_dir)


def find_hhc(decompiled: Path) -> Optional[Path]:
    files = list(decompiled.rglob("*.hhc"))
    return files[0] if files else None


def parse_hhc(hhc_path: Path) -> list[tuple[str, str, str]]:
    """Return list of (chapter_path, local_file, anchor)."""
    text = read_text(hhc_path)
    soup = BeautifulSoup(text, "html.parser")
    out: list[tuple[str, str, str]] = []

    def walk(ul, ancestors: list[str]):
        for li in ul.find_all("li", recursive=False):
            obj = li.find("object", recursive=False)
            name = local = None
            if obj is not None:
                for param in obj.find_all("param"):
                    pn = (param.get("name") or "").lower()
                    pv = param.get("value") or ""
                    if pn == "name" and name is None:
                        name = pv
                    elif pn == "local" and local is None:
                        local = pv
            new_anc = ancestors + ([name] if name else [])
            if local:
                anchor = ""
                if "#" in local:
                    local, anchor = local.split("#", 1)
                out.append((" › ".join(new_anc), local, anchor))
            nested = li.find("ul", recursive=False)
            if nested:
                walk(nested, new_anc)

    # Walk every UL whose ancestor is not an LI (i.e. top-level)
    for ul in soup.find_all("ul"):
        if ul.find_parent("li") is None:
            walk(ul, [])
    return out


def resolve_local(base: Path, local: str) -> Optional[Path]:
    """Resolve a TOC Local path against the decompiled dir, case-insensitive on Windows."""
    local = local.replace("\\", "/").lstrip("/")
    direct = base / local
    if direct.exists():
        return direct
    cur = base
    for part in local.split("/"):
        if not cur.is_dir():
            return None
        match = next((c for c in cur.iterdir() if c.name.lower() == part.lower()), None)
        if match is None:
            return None
        cur = match
    return cur if cur.exists() else None


def extract_text(html_path: Path) -> str:
    """Return plain-text content for indexing, or '' if the page is not
    indexable (broken encoding, empty, pure-boilerplate, or a navigation stub).
    Stub / empty pages are skipped so they don't pollute search results."""
    try:
        text = read_text(html_path)
    except Exception:
        return ""
    soup = BeautifulSoup(text, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    strip_boilerplate(soup)
    if looks_like_stub(soup):
        return ""
    return soup.get_text(separator=" ", strip=True)


def init_db(conn: sqlite3.Connection) -> str:
    """Create FTS5 table; prefer trigram tokenizer for CJK. Returns the tokenizer used."""
    cur = conn.cursor()
    for tokenizer in ("trigram", "unicode61"):
        try:
            cur.execute(f"""
                CREATE VIRTUAL TABLE IF NOT EXISTS docs USING fts5(
                    chm,
                    chapter,
                    html_path UNINDEXED,
                    anchor UNINDEXED,
                    content,
                    tokenize='{tokenizer}'
                )
            """)
            conn.commit()
            return tokenizer
        except sqlite3.OperationalError:
            continue
    raise RuntimeError("Could not create FTS5 table with any known tokenizer")


def main() -> int:
    ap = argparse.ArgumentParser(
        description=(
            "Build a shared SQLite FTS5 index over all CHM and HDX files in "
            "--chm-dir. Defaults: each file is decompiled to "
            "<chm-dir>/<name>_decompiled/, and a single shared index.db is "
            "written to <chm-dir>/index.db."
        )
    )
    ap.add_argument("--chm-dir", required=True,
                    help="Directory containing .chm and/or .hdx files")
    ap.add_argument("--out-dir",
                    help="(optional) common parent for the *_decompiled folders. "
                         "Default: same directory as --chm-dir.")
    ap.add_argument("--db",
                    help="(optional) path to the shared index.db. "
                         "Default: <chm-dir>/index.db.")
    ap.add_argument("--rebuild", action="store_true",
                    help="Drop the existing index before rebuilding.")
    args = ap.parse_args()

    chm_dir = Path(args.chm_dir).resolve()
    if not chm_dir.is_dir():
        print(f"ERROR: --chm-dir not found: {chm_dir}", file=sys.stderr)
        return 1

    out_dir = Path(args.out_dir).resolve() if args.out_dir else chm_dir
    db_path = Path(args.db).resolve() if args.db else (chm_dir / "index.db")

    out_dir.mkdir(parents=True, exist_ok=True)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    if args.rebuild and db_path.exists():
        db_path.unlink()

    conn = sqlite3.connect(db_path)
    tokenizer = init_db(conn)
    print(f"FTS5 tokenizer: {tokenizer}")
    print(f"Index: {db_path}")

    chms = sorted(
        list(chm_dir.glob("*.chm")) + list(chm_dir.glob("*.hdx"))
    )
    if not chms:
        print(f"No .chm or .hdx files in {chm_dir}", file=sys.stderr)
        return 1

    print(f"Found {len(chms)} CHM/HDX file(s)\n")

    grand_total = 0
    for chm in chms:
        target = out_dir / f"{chm.stem}_decompiled"
        already = target.exists() and any(target.rglob("*.hhc"))
        if already:
            print(f"[skip decompile] {chm.name}")
        else:
            print(f"[decompile] {chm.name} -> {target}")
            if not decompile_chm(chm, target):
                print(f"  FAILED, skipping")
                continue

        hhc = find_hhc(target)
        if hhc is None:
            print(f"  no .hhc found, skipping")
            continue

        entries = parse_hhc(hhc)
        print(f"  TOC entries: {len(entries)}")

        cur = conn.cursor()
        cur.execute("DELETE FROM docs WHERE chm = ?", (chm.name,))

        added = 0
        for chapter, local, anchor in entries:
            html = resolve_local(hhc.parent, local)
            if html is None:
                continue
            content = extract_text(html)
            if not content:
                continue
            cur.execute(
                "INSERT INTO docs (chm, chapter, html_path, anchor, content) "
                "VALUES (?, ?, ?, ?, ?)",
                (chm.name, chapter, str(html), anchor, content),
            )
            added += 1

        conn.commit()
        print(f"  indexed: {added}\n")
        grand_total += added

    conn.close()
    print(f"Done. Total indexed pages: {grand_total}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
