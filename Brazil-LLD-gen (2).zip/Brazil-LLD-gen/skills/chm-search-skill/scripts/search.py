#!/usr/bin/env python3
"""Search the CHM FTS5 index.

Usage:
    python search.py --db <index.db> -q "关键词" [--limit 10] [--chm name.chm] [--json]

Multiple terms are AND-combined.
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys

# Force UTF-8 on stdout/stderr so Chinese chars print correctly in Windows cmd
# (which defaults to GBK / CP936 and chokes on chars outside its table).
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, TypeError):
        pass


def build_match(query: str) -> str:
    terms = [t.strip() for t in query.split() if t.strip()]
    if not terms:
        return ""
    # Quote each term as a phrase to avoid FTS5 operator parsing of CJK punctuation.
    return " ".join(f'"{t}"' for t in terms)


def search(db_path: str, query: str, limit: int = 10, chm: str | None = None) -> list[dict]:
    match = build_match(query)
    if not match:
        return []

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    where = ["docs MATCH ?"]
    params: list = [match]
    if chm:
        where.append("chm = ?")
        params.append(chm)

    # Column-weighted BM25. The schema has three INDEXED columns (chm, chapter,
    # content) — UNINDEXED columns (html_path, anchor) don't participate in the
    # bm25() weight list. We boost `chapter` 10× over `content` because:
    #   - Technical docs use TOC chapter titles as canonical names of topics.
    #   - Bare full-text BM25 dilutes the title signal (long content pages
    #     score worse than short config/command snippets that just mention
    #     the term in passing). Weighting chapter floats the canonical page
    #     to the top.
    # NOTE: FTS5 returns NEGATIVE bm25 values; smaller (more negative) = better.
    sql = f"""
        SELECT chm, chapter, html_path, anchor,
               snippet(docs, 4, '<<<', '>>>', '...', 20) AS snippet,
               bm25(docs, 1.0, 10.0, 1.0) AS rank
        FROM docs
        WHERE {' AND '.join(where)}
        ORDER BY rank
        LIMIT ?
    """
    params.append(limit)

    out = []
    for row in cur.execute(sql, params):
        out.append({
            "chm": row["chm"],
            "chapter": row["chapter"],
            "html_path": row["html_path"],
            "anchor": row["anchor"],
            "snippet": row["snippet"],
        })
    conn.close()
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("-q", "--query", required=True)
    ap.add_argument("-n", "--limit", type=int, default=10)
    ap.add_argument("--chm", help="Filter to a single CHM filename")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    results = search(args.db, args.query, args.limit, args.chm)

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return 0

    if not results:
        print("(no matches)")
        return 0

    for i, r in enumerate(results, 1):
        anchor = f"#{r['anchor']}" if r["anchor"] else ""
        print(f"\n[{i}] {r['chm']}")
        print(f"    章节: {r['chapter']}")
        print(f"    路径: {r['html_path']}{anchor}")
        print(f"    片段: {r['snippet']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
