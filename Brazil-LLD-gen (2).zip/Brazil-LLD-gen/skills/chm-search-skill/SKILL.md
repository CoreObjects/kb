---
name: chm-search
description: >
  Index, search, and export content from CHM (.chm) and HDX (.hdx, Huawei
  HedEx) product manuals / 帮助文档 / 产品手册. ALWAYS use this skill instead
  of ad-hoc scripting whenever the user's task involves a .chm or .hdx file
  or a folder of such files. Specifically invoke when the user wants to
  (1) parse / decompile / index a CHM or HDX or a directory of them — 触发词
  "解析chm", "解析hdx", "解析产品手册", "构建索引", "建立索引", "索引手册",
  "parse chm", "parse hdx", "build index", "index manuals";
  (2) search across CHM/HDX manuals for a chapter, keyword, term, or topic —
  触发词 "搜索手册", "搜手册", "查找章节", "找一下…在哪", "在手册里找",
  "search chm", "search hdx"; (3) export a matched chapter / page into Word —
  触发词 "导出章节", "转成Word", "导出到docx", "抽取章节",
  "把这一节放到Word里". The skill ships three Python scripts
  (build_index.py, search.py, export.py) and a SQLite FTS5 trigram index
  suitable for Chinese full-text search. Both CHM and HDX are extracted via
  7-Zip; both expose a .hhc sitemap-format TOC inside the decompiled tree.
---

# CHM Search & Export Skill

## What it does
1. Extracts `.chm` and `.hdx` files (preferring **7-Zip**; falls back to `hh.exe -decompile` only for `.chm` if 7-Zip is unavailable). HDX is the Huawei HedEx package format — a zip-based container with the same sitemap-format `.hhc` TOC inside as CHM, so a single pipeline handles both.
2. Parses each archive's `.hhc` table-of-contents to recover the chapter tree.
3. Builds a **SQLite FTS5** full-text index keyed by `(chm, chapter_path, html_path, anchor, content)`. The `chm` column stores the source filename (which may be `*.chm` or `*.hdx`).
4. Provides keyword/phrase search returning chapter breadcrumbs + snippets.
5. Exports any matched HTML page to `.docx` via **pandoc**, after normalizing JS-tab structures so that all tab content is preserved as flat H2 sections.

## Files
- `scripts/build_index.py` — one-time / incremental indexing
- `scripts/search.py` — query the index (supports `--json`)
- `scripts/export.py` — single HTML page → docx, with tab normalization

## Prerequisites — MUST verify before invoking any script

Before running any of the three scripts, verify each required tool is
available. If a required tool is missing, tell the user to install it
first; do NOT silently fall back, skip steps, or attempt workarounds.

| Tool | Required by | Verify command | Install (Windows) |
|---|---|---|---|
| Python ≥ 3.10 with `beautifulsoup4` | all scripts | `python -c "import bs4"` (exit 0 = OK) | `pip install beautifulsoup4` |
| 7-Zip | `build_index.py` (CHM extraction) | `where 7z.exe` (or `Test-Path "C:\Program Files\7-Zip\7z.exe"`) | `winget install --id 7zip.7zip` |
| pandoc | `export.py` (HTML → docx) | `where pandoc` (exit 0 = OK) | `winget install --id JohnMacFarlane.Pandoc` |

Notes:
- If 7-Zip is absent, `build_index.py` will fall back to Windows `hh.exe -decompile`, but this fallback is unreliable on modern Windows (HTML Help deprecated since 2008, IE retired 2022, COM components frequently broken or blocked by EDR / Defender ASR). Always recommend installing 7-Zip first rather than relying on the fallback.
- pandoc is only needed at export time; indexing/searching can run without it. If the user only wants to build/search the index, you may proceed without pandoc and verify it later when an export is requested.

### Why 7-Zip instead of hh.exe?
The script extracts CHM via 7-Zip when available, and only falls back to the
built-in `hh.exe -decompile` if 7-Zip is not found. **7-Zip is strongly
preferred** because:

- HTML Help (CHM rendering) has been deprecated since 2008 and is fully
  unsupported since IE retired in 2022.
- `hh.exe -decompile` is an undocumented developer flag relying on internal
  COM components (`itcc.dll`, `hhctrl.ocx`) that are often unregistered or
  broken on modern Windows builds.
- Defender ASR rules and many EDR products silently block hh.exe operations
  (CHM is a known malware vector — it can embed JavaScript).
- 7-Zip treats CHM as what it really is — an ITSF compound file format —
  and extracts it like a regular archive, with no dependency on the
  deprecated HTML Help runtime.

The output layout (`.hhc` + `.html` + resources) is identical either way,
so downstream parsing (`parse_hhc`, indexing, export) is unaffected.

## Usage flow

### 1. Build / update the index
```bash
python scripts/build_index.py --chm-dir <folder containing .chm files>
```
**Defaults (no other flags needed):**
- Each `xxx.chm` is decompiled into `<chm-dir>/xxx_decompiled/` (next to the `.chm`).
- A single shared `index.db` is written at `<chm-dir>/index.db`, indexing every CHM in the folder. Each row carries a `chm` column so search results can be filtered to one CHM if needed.

Optional overrides:
- `--out-dir <path>`: put all `*_decompiled/` folders under a different parent (e.g. on another drive).
- `--db <path>`: store the shared index elsewhere.
- `--rebuild`: drop the existing index and rebuild from scratch.

Re-running without `--rebuild` skips already-decompiled CHMs and re-indexes only their TOC entries (cheap incremental update).

### 2. Search
```bash
python scripts/search.py --db <chm-dir>/index.db -q "散热系统" --json
```
Returns a JSON list:
```json
[
  {
    "chm": "CE8850.chm",
    "chapter": "硬件描述 › CE8850-64CQ-EI › 散热系统",
    "html_path": "E:\\...\\decompiled\\CE8850\\hw\\fans.html",
    "anchor": "",
    "snippet": "...支持<<<散热>>>风道前后..."
  }
]
```
- `chapter` is the breadcrumb from the TOC (separator `›`).
- Multi-keyword query: space-separated terms are AND-combined.
- Use `--chm <filename>` to filter to one CHM.

### 3. Export a chapter to Word
After picking a hit from search, hand its `html_path` to:
```bash
python scripts/export.py --html "<html_path>" --out chapter.docx
```
Optional: `--reference-doc template.docx` to apply a Word style template.

The export script:
- Detects ARIA tabs (`role="tablist"`/`role="tabpanel"`), Bootstrap-style tabs (`.nav-tabs` + `.tab-pane`), and class-name-based tab containers (`.tab-nav`, `.tab-head`, etc.).
- Rewrites each tab panel as an H2 heading + visible content, so the resulting Word doc has a clean linear structure instead of all panels mashed together.
- Falls back to un-hiding any remaining `display:none` block that contains substantial text.

## Architecture notes

### .hhc TOC tree
The `.hhc` file inside a decompiled CHM is an HTML "sitemap":
- `<UL>/<LI>` nesting = chapter hierarchy
- Each `<OBJECT type="text/sitemap">` has `<param name="Name">` (display title) and `<param name="Local">` (target HTML, optionally with `#anchor`)
- Multiple TOC entries can point to the same HTML file (page split into anchors).

`build_index.py` walks this tree depth-first and stores each leaf's full ancestor chain as `chapter`, so search results are immediately readable.

### Why FTS5 + trigram tokenizer
- Default `unicode61` tokenizer doesn't word-break Chinese. The `trigram` tokenizer (SQLite ≥ 3.34) indexes overlapping 3-character grams, giving correct substring matching for CJK with no external tokenizer.
- Falls back to `unicode61` automatically if trigram isn't available in the bundled SQLite.

### Encoding

**Input side** (file decoding): `.hhc` and `.html` files in Chinese-vendor CHMs are commonly **GBK / GB18030**. Both indexer and exporter try `utf-8 → gbk → gb18030 → big5 → latin-1` in order before giving up.

**Output side** (script stdout/stderr): all three scripts reconfigure `sys.stdout` and `sys.stderr` to `utf-8` at startup so Chinese chapter names, file names, snippets, and diagnostic logs print correctly in Windows `cmd.exe` (which defaults to GBK / CP936 and would otherwise either show mojibake or raise `UnicodeEncodeError` on chars outside the GBK table). The fallback `errors="replace"` ensures stray pathological chars degrade to `?` rather than crashing the script. No action needed by the caller.

**Image src URI schemes** (in HTML): in addition to plain relative/absolute paths, the exporter recognises CHM-internal Microsoft URI monikers and rewrites them to on-disk paths under the decompile root:
- `mk:@MSITStore:[name.chm]::/path/inside.png`
- `ms-its:[name.chm]::/path/inside.png`
- `its:[name.chm]::/path/inside.png`

The `::`-delimited inner path is what 7-Zip extraction places under each CHM's `*_decompiled/` folder.

## Limitations / known issues
- **JS-fetched tab content** (page that XHRs for tab body on click) won't be picked up by static parsing. If a page's docx export comes out suspiciously short, fall back to manual review or add a Playwright render step.
- `hh.exe -decompile` occasionally exits before finishing. The indexer waits up to ~30s after invocation for files to appear before giving up.
- TOC entries pointing to missing/renamed HTML files are silently skipped (logged in stdout).
