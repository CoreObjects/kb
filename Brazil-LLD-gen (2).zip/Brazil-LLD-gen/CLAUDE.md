# BRAZIL-LLD-GEN — Claude Code Guide

## Project Overview

This project generates Low-Level Design (LLD) documents for Brazilian telecom network projects. Given a device list (from Excel or conversation), it searches Huawei product manuals (CHM/HDX) and produces formatted Word (.docx) hardware chapter documents.

## Directory Structure

```
BRAZIL-LLD-GEN/
├── CLAUDE.md                          ← you are here
├── config.yaml                        ← project paths (read this first)
├── input/                             ← user uploads (Excel, device lists)
├── output/                            ← generated documents
├── references/                        ← reference LLDs and templates
│   └── manuals/                       ← CHM/HDX zip files (product manuals)
├── manuals/                           ← extracted CHM files + index.db
└── skills/
    ├── chm-search-skill/scripts/
    │   ├── build_index.py             ← one-time CHM indexing
    │   └── search.py                  ← search index.db
    └── hardware-chapter-gen/scripts/
        ├── parse_device_list.py       ← Excel → device list JSON
        ├── explore_chapters.py        ← device model → candidate chapters
        ├── gen_hardware_chapter.py    ← chapter_plan → hardware_chapter.docx
        └── render_docx.js             ← markdown → docx (called by gen script)
```

## Config

Always read `config.yaml` first to get correct paths:

```yaml
db_path:       manuals/index.db
search_script: skills/chm-search-skill/scripts/search.py
explore_script: skills/hardware-chapter-gen/scripts/explore_chapters.py
gen_script:    skills/hardware-chapter-gen/scripts/gen_hardware_chapter.py
output_dir:    output/
chapter_start: "3.3"
```

All paths in config.yaml are relative to the project root.

------

## Workflow: Excel → LLD Hardware Chapter

When the user asks to generate a hardware chapter from an Excel device list, follow these steps in order.

### Step 1 — Parse Excel

```bash
python skills/hardware-chapter-gen/scripts/parse_device_list.py \
  --excel input/<filename>.xlsx \
  --out output/device_list.json
```

Read `output/device_list.json`. It contains:

- `devices`: network devices to process (CE switches etc.)
- `skipped`: servers/appliances automatically excluded (2288H etc.)

Report the device list to the user and confirm before proceeding.

### Step 2 — Explore chapters (one per device)

For each device in `devices`, run:

```bash
python skills/hardware-chapter-gen/scripts/explore_chapters.py \
  --model "<Device Model>" \
  --db manuals/index.db \
  --search-script skills/chm-search-skill/scripts/search.py \
  --out output/candidates_<model>.json \
  --top-k 10
```

### Step 3 — Classify candidates into chapter_plan

Read each `candidates_<model>.json`. For each candidate, classify by examining the `chapter` breadcrumb field:

| Role               | Breadcrumb pattern                                           |
| ------------------ | ------------------------------------------------------------ |
| `appearance`       | contains "Product Appearance" or "Product Description"       |
| `chassis_overview` | contains "Chassis › {model}" — pick ONE, prefer 02351RFF-004 over 001 |
| `specifications`   | contains "Specifications"                                    |
| `sub_component`    | contains "Power Module" or "Fan Module" (optional)           |
| skip               | Installation, Configuration, Command Reference, other models |

Build a `chapter_plan.json` for each device:

```json
{
  "model": "CE8850-64CQ-EI",
  "sections": [
    {
      "html_path": "...dc_dc_88_pd_0002_v2r20c10.html",
      "chapter": "...Product Appearance",
      "role": "appearance",
      "section_title": "CE8850-64CQ-EI Bayface Design",
      "max_images": 3
    },
    {
      "html_path": "...ce_box_chassis_02351RFF-004.html",
      "chapter": "...Chassis › CE8850-64CQ-EI",
      "role": "chassis_overview",
      "section_title": "Componentes de Hardware CE8850-64CQ-EI",
      "max_images": 0
    }
  ]
}
```

Key rules:

- `appearance` → `max_images: 3`, images shown BEFORE tables
- `chassis_overview` → `max_images: 0`, no images
- `sub_component` → `max_images: 1`, include only if clearly useful
- Never include Installation, Configuration Guide, or Command Reference pages
- If the same model has multiple chassis part numbers (02351RFF-001, 02351RFF-004), pick only ONE (prefer the higher suffix)

### Step 4 — Generate docx

For each device, run:

```bash
python skills/hardware-chapter-gen/scripts/gen_hardware_chapter.py \
  --chapter-plan output/chapter_plan_<model>.json \
  --out-dir output/<model>/ \
  --chapter-start 3.3
```

Output: `output/<model>/hardware_chapter.docx`

### Step 5 — Report to user

Tell the user:

- Which devices were processed
- Which were skipped (servers)
- Where each docx was saved
- Any devices where no manual content was found

------

## Workflow: Single device (no Excel)

When user says "generate hardware chapter for CE8850-64CQ-EI":

1. Run Step 2 (explore_chapters) directly with the model name
2. Classify candidates (Step 3)
3. Run Step 4 (gen_hardware_chapter)
4. Report output path

------

## Chapter numbering

Default `--chapter-start` is `3.3` (from config.yaml). When generating multiple devices from one Excel, increment per device:

- First device: `3.3`
- Second device: `3.4`  (adjust based on sub-section count of previous device)
- Third device: `3.5`

Or ask the user what chapter number to start from.

------

## Prerequisites check

Before running any script, verify:

```bash
# Python deps
python -c "import bs4, openpyxl, yaml; print('OK')"

# Node deps (for docx rendering)
node -e "require('docx'); console.log('OK')"

# index.db exists
python -c "from pathlib import Path; assert Path('manuals/index.db').exists(), 'Run build_index.py first'"
```

If `index.db` is missing, run:

```bash
python skills/chm-search-skill/scripts/build_index.py \
  --chm-dir manuals \
  --db manuals/index.db
```

(This takes a few minutes on first run — the script auto-extracts zips.)

------

## Output language

- Section titles: Portuguese (Introdução, Componentes de Hardware, Especificações Técnicas)
- Technical terms and content: English (from Huawei manuals, kept as-is)
- User communication: match the user's language

------

## Common issues

| Problem                      | Solution                                                  |
| ---------------------------- | --------------------------------------------------------- |
| `index.db` not found         | Run build_index.py (auto-triggered if --chm-dir provided) |
| `No content found for model` | Model not in indexed manuals; check CHM coverage          |
| `Cannot find module 'docx'`  | Run `npm install docx` in scripts/ directory              |
| `openpyxl not installed`     | Run `pip install openpyxl`                                |
| Images not appearing         | Check if `figure/` directory exists in decompiled CHM     |